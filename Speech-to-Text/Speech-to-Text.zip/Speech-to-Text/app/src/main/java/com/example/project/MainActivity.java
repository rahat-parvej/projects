package com.example.project;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private EditText textout;
    private Button sttbtn;
    private Button ttsbtn;
    TextToSpeech tts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textout=(EditText) findViewById(R.id.editTextTextMultiLine);
        textout.setEnabled(false);
        sttbtn= findViewById(R.id.sttbtn);
        ttsbtn=findViewById(R.id.tts_btn);
        ttsbtn.setEnabled(false);


        sttbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
                try {
                    startActivityForResult(intent, 100);

                }catch (ActivityNotFoundException e){
                    Toast.makeText(getApplicationContext(),"Your Device Don't Support Speech Input",Toast.LENGTH_SHORT).show();
                }
                /*if (intent.resolveActivity(getPackageManager()) != null) {
                    startActivityForResult(intent, 100);
                } else {
                    Toast.makeText(getApplicationContext(),"Your Device Don't Support Speech Input",Toast.LENGTH_SHORT).show();

                }*/

            }
        });
        tts= new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if(status==TextToSpeech.SUCCESS){
                    tts.setLanguage(Locale.getDefault());
                }
            }
        });

        ttsbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text= textout.getText().toString();

                tts.speak(text,TextToSpeech.QUEUE_FLUSH,null);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode){
            case 100:{
                if(resultCode==RESULT_OK && null!=data){
                    ArrayList<String> resutl= data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    textout.setText(resutl.get(0));
                    textout.setEnabled(true);
                    ttsbtn.setEnabled(true);
                }
            }
        }
    }

}