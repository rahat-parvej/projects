
  <section class=" text-white footer" id="" style="background:#000 ">
    <div class="container">
      <div class="row py-4">
        <div class="col-md-6 my-auto">
          <a class="footer-logo text-decoration-none" href="index.php"
            style="font-family: 'Indie Flower', cursive;font-size: 35px; font-weight: 800;"><span class="text-danger"
              style="font-family: 'Nosifer', cursive;">Abortion</span> Help</a>
              <ul class="pt-4 social">
                <li><a href="" target="_blank" rel="noopener noreferrer"><i class="fa-brands fa-facebook"></i></a></li>
                <li><a href="" target="_blank" rel="noopener noreferrer"><i class="fa-brands fa-twitter-square"></i></a></li>
                <li><a href="" target="_blank" rel="noopener noreferrer"><i class="fa-solid fa-square-envelope"></i></a></li>
              </ul>
        </div>
        <div class="col-md-6">
          <p>Abortion Help delivers vital reproductive health care, sex education, and information to millions of people
            worldwide.</p>
            <h5>Usefull Links</h5>
          <ul>
            <li><a href="http://">Abortion</a></li>
            <li><a href="http://">About Us</a></li>
            <li><a href="http://">Contact Us</a></li>
            <li><a href="http://">Hospital List</a></li>
            <li><a href="http://">About Us</a></li>
          </ul>
        </div>
      </div>
      <div class="row border-top pt-3 pb-5 text-center">
        
        <?php include "developers.php" ?>
        
      </div>
    </div>
  </section>

  
  <script src="js/vendor/modernizr-3.11.2.min.js"></script>
  <script src="js/plugins.js"></script>
  <script src="js/main.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
  <script src="js/jquery-3.6.0.min.js"></script>
  
  <!-- Google Analytics: change UA-XXXXX-Y to be your site's ID. -->
  <script>
    window.ga = function () { ga.q.push(arguments) }; ga.q = []; ga.l = +new Date;
    ga('create', 'UA-XXXXX-Y', 'auto'); ga('set', 'anonymizeIp', true); ga('set', 'transport', 'beacon'); ga('send', 'pageview')
  </script>
  <script src="https://www.google-analytics.com/analytics.js" async></script>
</body>

</html>
