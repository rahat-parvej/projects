<?php 
    include "header.php";
    include "dbcon/dbcon.php";
    //print_r($_POST);
    $Division=$_POST['division'] ;
    $District=$_POST['District'];
    $Upazila=$_POST['Upazila'];
?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php
                    
                    $result = mysqli_query($conn,"SELECT COUNT(Org_Code) FROM `hospital_list` WHERE Division='$Division' AND District='$District' AND Upazila='$Upazila'");
                    $row = mysqli_fetch_array($result);
                    //print_r ($row);
                ?>
                <h1 class="text-center py-3"><span class="text-success"><?php echo $row['0'];?></span> Health Center Near <?php echo $Upazila;?> Upazila</h1>
                <?php 
                    $sql=$result=$row="";
                    $sql = "SELECT * FROM `hospital_list` WHERE Division='$Division' AND District='$District' AND Upazila='$Upazila'";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                    // output data of each row
                        while($row = $result->fetch_assoc()) {
                            //print_r($row);
                            ?>
                            <div class="card mb-3">
                                <div class="card-header">
                                   <span class="fw-bold fs-4 text-capitalize"><?php echo $row['Name']; ?></span> 
                                </div>
                                <div class="card-body">
                                    <h5 class="card-title">Mobile: <span><a class="text-decoration-none" href="tel:+88<?php echo trim($row['Mobile_Phones']);?>"><?php echo trim($row['Mobile_Phones']);?></a></span></h5>
                                    <h5>Phone: <span><a class="text-decoration-none" href="tel:+88<?php echo trim($row['Land_Phones']);?>"><?php echo trim($row['Land_Phones']);?></a></span></h5>
                                    <h5>Email: <span><a class="text-decoration-none" href="mailto:<?php echo $row['Email'];?>"><?php echo $row['Email'];?></a></span></h5>
                                    <p class="fw-bold">Organization Type: <span class="fw-normal"><?php echo $row['Org_Type'];?></span><span class="float-end fw-normal"><span class="fw-bold">Union Name: </span><?php echo $row['Union_p']; ?></span></p>
                                    <?php if($row['Mailing_Address']!=""){
                                        echo "<p class='fw-bold'>Address: <span class='fw-normal'>".$row['Mailing_Address']."</span></p>";
                                        } ?>
                                </div>
                            </div>
                            <?php
                        }
                    } else {
                        echo "0 results";
                    }
                ?>
                
            </div>
        </div>
    </div>


<?php include "footer.php"; ?>