<?php
    $servername = "localhost";
    $username = "sellenzins_abortion";
    $password = "Lb$6uq+&Swtk";
    $dbname = "sellenzins_abortion_help";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
?>