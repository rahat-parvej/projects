<?php
    session_start();
    $_SESSION['email']=$_SESSION['Org_Code']="";
    
        include "dbcon/dbcon.php";
        if ($_SERVER["REQUEST_METHOD"] == "POST"){
            if(!empty($_POST['login_email']) && !empty($_POST['login_pass'])){
                $login_email= filter_var($_POST['login_email'], FILTER_SANITIZE_EMAIL);
                $login_pass= filter_var($_POST['login_pass'], FILTER_SANITIZE_STRING);
                
                $sql="";
                $sql="SELECT * FROM user WHERE email='$login_email'";
                $result = $conn->query($sql);
                $row = $result->fetch_assoc();
                if($login_email==$row['email'] && md5($login_pass)==$row['password']){
                    
                    $_SESSION['email']=$login_email;
                    $_SESSION['Org_Code']=$row['Org_Code'];
                    if($row['Org_Code']!='admin'){
                        header("Location: hospitals/");
                        exit();
                    }else{
                        header("Location: admin/");
                        exit();
                    }
                    
                }
                else{
                    echo "Wrong";
                }
            }
        }else{
            echo "<script>alert('Loged Out');window.location.replace('index.php');</script>";
            // remove all session variables
            session_unset();

            // destroy the session
            session_destroy();
        }
    
    
?>