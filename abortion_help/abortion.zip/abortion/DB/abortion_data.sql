-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 25, 2022 at 02:06 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `abortion_help`
--

-- --------------------------------------------------------

--
-- Table structure for table `abortion_data`
--

CREATE TABLE `abortion_data` (
  `Date` date NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Age` int(11) NOT NULL,
  `District` varchar(20) NOT NULL,
  `Marital_Status` varchar(10) NOT NULL,
  `Cause` varchar(100) NOT NULL,
  `Religion` varchar(25) NOT NULL,
  `Name_of_Hospital` varchar(200) NOT NULL,
  `Type` varchar(100) NOT NULL,
  `Baby_Death` varchar(10) NOT NULL,
  `Mother_Death` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `abortion_data`
--

INSERT INTO `abortion_data` (`Date`, `Name`, `Age`, `District`, `Marital_Status`, `Cause`, `Religion`, `Name_of_Hospital`, `Type`, `Baby_Death`, `Mother_Death`) VALUES
('2022-07-04', 'Mukti', 30, 'Rangpur ', 'Married ', '', 'Hindu', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-07-03', 'Tahamina', 50, 'Panchagarh ', 'Married ', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-07-02', 'Romjin', 38, 'Nilphamari ', 'Married ', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-07-01', 'Khurshida Begum', 25, 'Thakurgaon ', 'Married ', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-07-01', 'Aklima', 50, 'Kurigram ', 'Married ', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-07-01', 'Ferdousi', 35, 'Gaibandha', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-06-30', 'Rima', 25, 'Panchagarh ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-06-29', 'Mou', 21, 'Thakurgaon ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-06-28', 'Najmin', 20, 'Rangpur ', 'Married ', '', 'Islam', 'RpMCH', 'Missed Abortion', 'Yes', 'No'),
('2022-06-27', 'Aysha', 20, 'Gaibandha', 'Married ', '', 'Islam', 'RpMCH', 'Missed Abortion', 'Yes', 'No'),
('2022-06-26', 'Laizu', 30, 'Kurigram', 'Married', '', 'Islam', 'RpMCH', 'Complete Abortion ', 'Yes', 'No'),
('2022-06-25', 'Khadiza', 32, 'Nilphamari ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-06-24', 'Shirin', 25, 'Panchagarh ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-06-23', 'Anjuman', 30, 'Kurigram ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-06-22', 'Ashura', 19, 'Lalmonirhat ', 'Married ', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-06-21', 'Angura Khatun', 22, 'Lalmonirhat ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-06-20', 'Kobira', 20, 'Rangpur ', 'Married ', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-06-19', 'Kolpona', 28, 'Nilphamari ', 'Married', '', 'Hindu', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-06-18', 'Moyna', 45, 'Thakurgaon ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-06-17', 'Momotaz', 25, 'Gaibandha', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-06-16', 'Nurunnahar', 35, 'Lalmonirhat ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-06-15', 'Sadeka', 30, 'Panchagarh ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-06-14', 'Kolpona', 30, 'Kurigram ', 'Married', '', 'Islam', 'RpMCH', 'Complete Abortion ', 'Yes', 'No'),
('2022-06-13', 'Jesmin', 28, 'Nilphamari ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-06-12', 'Mostakina', 20, 'Thakurgaon ', 'Married ', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-06-11', 'Sumaiya', 20, 'Lalmonirhat ', 'Married ', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-06-11', 'Arju Begum', 30, 'Panchagarh ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-06-11', 'Shimu Akhter', 20, 'Gaibandha', 'Married ', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-06-10', 'Airin ', 18, 'Kurigram ', 'Married ', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-06-10', 'Sharmin', 21, 'Rangpur ', 'Married', '', 'Islam', 'RpMCH', 'Complete Abortion ', 'Yes', 'No'),
('2022-06-10', 'Arjina', 40, 'Lalmonirhat ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-06-09', 'Tahmin', 40, 'Nilphamari ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-06-09', 'Sumi', 40, 'Thakurgaon ', 'Married', '', 'Hindu', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-06-08', 'Laboni', 28, 'Panchagarh ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-06-07', 'Allin', 30, 'Gaibandha', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-06-06', 'Rumi', 40, 'Lalmonirhat ', 'Married', '', 'Islam', 'RpMCH', 'Complete Abortion ', 'Yes', 'No'),
('2022-06-05', 'Fenis', 36, 'Kurigram', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-05-05', 'Hasina', 31, 'Rangpur ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-06-04', 'Shahinur', 32, 'Kurigram ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-06-03', 'Shujana', 21, 'Thakurgaon ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-06-02', 'Fenis', 40, 'Panchagarh ', 'Married', '', 'Islam', 'RpMCH', 'Complete Abortion ', 'Yes', 'No'),
('2022-06-01', 'Anos', 45, 'Nilphamari ', 'Married', '', 'Islam', 'RpMCH', 'Complete Abortion ', 'Yes', 'No'),
('2022-05-31', 'Parvin', 38, 'Lalmonirhat ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-05-30', 'Borsha', 20, 'Thakurgaon ', 'Married ', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-05-29', 'Narjina', 42, 'Panchagarh ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-05-28', 'Bithi', 22, 'Gaibandha', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-05-27', 'Rubeya', 30, 'Rangpur ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-05-26', 'Lota Rani', 30, 'Lalmonirhat ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-05-25', 'Sharmin ', 30, 'Thakurgaon ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-05-24', 'Firoza', 35, 'Panchagarh ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-05-23', 'Moushumi', 27, 'Lalmonirhat ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-05-22', 'Shahinur Begum', 35, 'Rangpur ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-05-21', 'Monija', 18, 'Gaibandha', 'Married ', '', 'Islam', 'RpMCH', 'Complete Abortion ', 'Yes', 'No'),
('2022-05-20', 'Samina', 43, 'Kurigram ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-05-19', 'Bithi', 18, 'Nilphamari ', 'Married ', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-05-18', 'Shurovi', 44, 'Panchagarh ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-05-17', 'Moyna', 30, 'Thakurgaon ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-05-16', 'Smrity', 28, 'Lalmonirhat ', 'Married', '', 'Islam', 'RpMCH', 'Complete Abortion ', 'Yes', 'No'),
('2022-05-15', 'Shurovi', 22, 'Rangpur ', 'Married', '', 'Islam', 'RpMCH', 'Complete Abortion ', 'Yes', 'No'),
('2022-05-14', 'Mishti', 30, 'Gaibandha', 'Married', '', 'Hindu', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-05-13', 'Munni Begum', 28, 'Lalmonirhat ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-05-12', 'Bijli', 25, 'Kurigram ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-04-30', 'Naznin', 30, 'Panchagarh ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-04-29', 'Merina', 23, 'Nilphamari ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-04-28', 'Shamsunnahar ', 28, 'Thakurgaon ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-04-27', 'Parvin', 30, 'Lalmonirhat ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-04-26', 'Renuka', 25, 'Gaibandha', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-04-25', 'Chadni', 36, 'Rangpur ', 'Married', '', 'Hindu', 'RpMCH', 'Complete Abortion ', 'Yes', 'No'),
('2022-04-24', 'Shapla', 25, 'Lalmonirhat ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-04-20', 'Rozina', 25, 'Kurigram ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-04-19', 'Sharmin', 30, 'Thakurgaon ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-04-18', 'Arifa', 19, 'Panchagarh ', 'Married ', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-04-17', 'Lili Begum', 35, 'Nilphamari ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-04-16', 'Suma', 22, 'Gaibandha', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-04-15', 'Tanzina', 22, 'Thakurgaon ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-04-14', 'Habiba', 19, 'Rangpur ', 'Married ', '', 'Islam', 'RpMCH', 'Complete Abortion ', 'Yes', 'No'),
('2022-04-13', 'Arzina', 25, 'Lalmonirhat ', 'Married', '', 'Islam', 'RpMCH', 'Complete Abortion ', 'Yes', 'No'),
('2022-04-12', 'Rozina', 28, 'Kurigram ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-04-11', 'Ritu', 20, 'Lalmonirhat ', 'Married ', '', 'Hindu', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-04-10', 'Isron', 32, 'Thakurgaon ', 'Married', '', 'Islam', 'RpMCH', 'Complete Abortion ', 'Yes', 'No'),
('2022-04-09', 'Sharmin ', 30, 'Rangpur ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-04-08', 'Joba', 20, 'Lalmonirhat ', 'Married ', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-04-07', 'Masuda', 25, 'Gaibandha', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-04-06', 'Monzila', 27, 'Lalmonirhat ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-04-05', 'Arifa', 20, 'Panchagarh ', 'Married ', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-04-03', 'Shahinur', 32, 'Nilphamari ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-04-02', 'Papri', 27, 'Thakurgaon ', 'Married', '', 'Hindu', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-04-01', 'Reshmi', 35, 'Rangpur ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-04-01', 'Halima', 18, 'Lalmonirhat ', 'Married ', '', 'Islam', 'RpMCH', 'Complete Abortion ', 'Yes', 'No'),
('2022-03-31', 'Rabeya', 32, 'Gaibandha', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-03-29', 'Mostakina', 20, 'Kurigram ', 'Married ', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-03-27', 'Chiana begum', 32, 'Thakurgaon ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-03-25', 'Lipi', 28, 'Lalmonirhat ', 'Married', '', 'Hindu', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-03-23', 'Mosfeka', 25, 'Panchagarh ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-03-21', 'Rumi', 35, 'Kurigram ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-03-19', 'Rohima', 30, 'Nilphamari ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-03-17', 'Nargis', 35, 'Rangpur ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-03-15', 'Moriom', 17, 'Lalmonirhat ', 'Married ', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-03-13', 'Nasrin', 50, 'Gaibandha', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-03-11', 'Nazmin', 30, 'Thakurgaon ', 'Married', '', 'Islam', 'RpMCH', 'Complete Abortion ', 'Yes', 'No'),
('2022-03-09', 'Khadiza', 36, 'Kurigram ', 'Married', '', 'Islam', 'RpMCH', 'Complete Abortion ', 'Yes', 'No'),
('2022-03-07', 'Reshma', 26, 'Panchagarh ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-03-05', 'Mina Rani', 30, 'Lalmonirhat ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-03-03', 'Kulshum', 25, 'Rangpur ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-03-01', 'Murshida', 20, 'Nilphamari ', 'Married ', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-02-28', 'Mukti', 20, 'Thakurgaon ', 'Married ', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-02-27', 'Shirin', 27, 'Panchagarh ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-02-26', 'Shantona', 25, 'Kurigram ', 'Married', '', 'Hindu', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-02-25', 'Shirin', 30, 'Gaibandha', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-02-24', 'Rowshon Jannat', 35, 'Rangpur ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-02-23', 'Nilufa', 30, 'Lalmonirhat ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-02-22', 'Karina', 22, 'Thakurgaon ', 'Married', '', 'Islam', 'RpMCH', 'Complete Abortion ', 'Yes', 'No'),
('2022-02-21', 'Joynob', 35, 'Nilphamari ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-02-20', 'Shiuli', 35, 'Lalmonirhat ', 'Married', '', 'Hindu', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-02-19', 'Jesina', 40, 'Kurigram ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-02-18', 'Marufa', 33, 'Rangpur ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-02-17', 'Ruma Akhter', 35, 'Thakurgaon ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-02-16', 'Nargis', 35, 'Lalmonirhat ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-02-15', 'Shahinur', 20, 'Kurigram ', 'Married ', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-02-14', 'Mohona', 22, 'Panchagarh ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-02-13', 'Mashrufa', 40, 'Nilphamari ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-02-12', 'Kajoli', 26, 'Lalmonirhat ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-02-11', 'Roshni', 40, 'Thakurgaon ', 'Married', '', 'Islam', 'RpMCH', 'Complete Abortion ', 'Yes', 'No'),
('2022-02-10', 'Chobita', 35, 'Rangpur ', 'Married', '', 'Hindu', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-02-09', 'Doyali', 28, 'Kurigram ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-02-08', 'Airin', 20, 'Gaibandha', 'Married ', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-02-07', 'Ashamoni', 25, 'Panchagarh ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-02-06', 'Beli', 24, 'Thakurgaon ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-02-05', 'Nargis', 32, 'Nilphamari ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-02-04', 'Mim', 24, 'Lalmonirhat ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-02-03', 'Sabina', 40, 'Rangpur ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-02-02', 'Khadija', 25, 'Thakurgaon ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-02-01', 'Achiya', 30, 'Lalmonirhat ', 'Married', '', 'Islam', 'RpMCH', 'Complete Abortion ', 'Yes', 'No'),
('2022-01-31', 'Selina', 50, 'Kurigram ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-01-29', 'Bobita', 25, 'Panchagarh ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-01-27', 'Sohagi', 25, 'Thakurgaon ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-01-25', 'Anowara', 40, 'Rangpur ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-01-23', 'Morsheda', 40, 'Nilphamari ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-01-21', 'Shumi', 19, 'Lalmonirhat ', 'Married ', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-01-19', 'Nobiya', 28, 'Gaibandha', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-01-17', 'Amena', 30, 'Lalmonirhat ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-01-15', 'Shahnaz', 23, 'Thakurgaon ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-01-13', 'Jyoti', 25, 'Nilphamari ', 'Married', '', 'Hindu', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-01-11', 'Shumi Rani', 40, 'Rangpur ', 'Married', '', 'Islam', 'RpMCH', 'Complete Abortion ', 'Yes', 'No'),
('2022-01-09', 'Moushumi ', 24, 'Kurigram ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-01-07', 'Shapla', 22, 'Lalmonirhat ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-01-05', 'Rozi', 25, 'Gaibandha', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-01-03', 'Sumi', 35, 'Thakurgaon ', 'Married', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No'),
('2022-01-01', 'Nazma', 20, 'Rangpur ', 'Married ', '', 'Islam', 'RpMCH', 'Incomplete Abortion  ', 'Yes', 'No');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
