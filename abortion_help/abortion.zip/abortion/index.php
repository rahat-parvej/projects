<?php
  include "header.php";
?>

  <!-- Add your site or application content here -->
  
  <section class="" id="" style="background:#2895d5;">
    <div class="container p-4">
      <div class="row">
        <div class="col-md-6 text-white">
          <h2 class="fw-bolder">Abortion in Bangladesh is illegal under most situations, but menstrual regulation is often used as a substitute</h2>
          <p class="fw-bold fs-6">Bangladesh is still governed by the penal code from 1860, where induced abortion is illegal unless the woman is in danger</p>
        </div>
        <div class="col-md-6 text-center align-items-center my-auto">
          <a href="learn/abortion/?page=it-still-legal-me-get-abortion"><button type="button" class="btn btn-lg text-white rounded-pill" style="background:#00286e">Learn More</button></a>
          
        </div>
      </div>
    </div>

  </section>

  <section class="home_banner " id="health_center">
    <div class="bg-overlay" style="padding-top:7rem;padding-bottom:3.2rem">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="row" id="">
              <div class="col-md-6"></div>
              <div class="col-md-6 mb-3 px-5 banner_text">
                <h2 class="fw-bolder mb-2">Abortion Help Stands for Care</h2>
                <p class="fw-normal fs-5 pe-3">Your health is the highest priority and we believe your body is your own.
                  Make an in-person or telehealth appointment online</p>
              </div>
            </div>
          </div>
          <div class="col-md-12 bg-light p-3 rounded find_helth_center">
            <h2>Find a Health Center</h2> <br>
            <form action="hospitalfinder.php" method="post" class="row g-3">
            
              <div class="col-md-3">
                <select name="division" class="form-select" id="divisions" onchange="divisionsList();">
                  <option disabled selected>Select Division</option>
                  <option value="Barishal">Barishal</option>
                  <option value="Chattogram">Chattogram</option>
                  <option value="Dhaka">Dhaka</option>
                  <option value="Khulna">Khulna</option>
                  <option value="Mymensingh">Mymensingh</option>
                  <option value="Rajshahi">Rajshahi</option>
                  <option value="Rangpur">Rangpur</option>
                  <option value="Sylhet">Sylhet</option>
                </select>
              </div>
              <div class="col-md-3">
                <select name="District" class="form-select" id="distr" onchange="thanaList();" required>
                  <option disabled selected>Select District</option>
                </select>
              </div>
              <div class="col-md-3">
                <select name="Upazila" class="form-select" id="polic_sta" required>
                  <option disabled selected>Select Upazila</option>
                </select>
              </div>
              <div class="col-md-3">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>
              
              
            
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="py-5 bg-white" id="" style="">
    <div class="container">
      <div class="row">
        <div class="col-md-3 text-center mb-2">
          <img src="img/condoms.png" alt="" srcset="" class="img-fluid mb-5" style="width:65px">
          <h3 class="mb-3 fs-4">STDs</h3>
          <p class="px-4 fs-5 mb-3">Sexually transmitted infections are passed during sexual contact. Learn more about STD symptoms, testing, and treatment. <br><br></p>
          <a href=""> <button type="button" class="btn btn-primary btn-lg rounded-pill fw-bold">Learn More </button></a>
        </div>
        <div class="col-md-3 text-center mb-2">
          <img src="img/birthcontrol.png" alt="" srcset="" class="img-fluid mb-5" style="width:65px">
          <h3 class="mb-3 fs-4">Birth Control</h3>
          <p class="px-4 fs-5 mb-3">Birth control lets you prevent and plan the timing of pregnancy. Compare birth control options and find the best method for you. <br><br></p>
          <a href=""> <button type="button" class="btn btn-primary btn-lg rounded-pill fw-bold">Learn More </button></a>
        </div>
        <div class="col-md-3 text-center mb-2">
          <img src="img/pills.png" alt="" srcset="" class="img-fluid mb-5" style="width:65px">
          <h3 class="mb-3 fs-4">Emergency Contraception (Morning-After Pill)</h3>
          <p class="px-4 fs-5 mb-3">Emergency contraception safely and effectively prevents pregnancy up to five days after unprotected sex.</p>
          <a href=""> <button type="button" class="btn btn-primary btn-lg rounded-pill fw-bold">Learn More </button></a>
        </div>
        <div class="col-md-3 text-center mb-2">
          <img src="img/clinic.png" alt="" srcset="" class="img-fluid mb-5" style="width:65px">
          <h3 class="mb-3 fs-4">Abortion</h3>
          <p class="px-4 fs-5 mb-3">Abortion is a safe way to end a pregnancy. Get the facts about the abortion pill and in-clinic abortion. <br><br><br></p>
          <a href=""> <button type="button" class="btn btn-primary btn-lg rounded-pill fw-bold">Learn More </button></a>
        </div>
        
      </div>
      <div class="row pt-5">
        <div class="col-md-12 text-center">
        <button type="button" class="btn btn-outline-dark btn-lg rounded-pill">See All Topics</button>
        </div>
      </div>
    </div>
  </section>

  <section class="py-5 app-link" id="" style="background:#acd9f4; color:#333740">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <div class="ratio ratio-16x9">
            <iframe src="https://www.youtube.com/embed/zDhvmYBLeio" title="YouTube video player" frameborder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowfullscreen class="rounded"></iframe>
          </div>

        </div>
        <div class="col-md-6">
          <h2 class="fw-bolder mb-2">Get birth control pills delivered to your door.</h2>
          <p class="fw-normal fs-5 pe-3">With the Planned Parenthood Direct app, you'll have unlimited access to our
            expert doctors and nurses. It's reproductive health care anytime, anywhere—no appointment needed. Download
            the app today.</p>

          <a target="_blank" rel="noopener noreferrer"
            href="https://play.google.com/store/apps/details?id=com.lifeplusbd.user"><img src="img/glpay.PNG"
              class="img-fluid" width="150" alt="..."></a>

        </div>
      </div>
    </div>
  </section>

  <section class="py-4" id="" style="background:#840855; color:#fff">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <h2 class="fw-bolder mb-2">Supreme Court Allows States to Ban Abortion, Roe v. Wade Overturned</h2>
          <p class="fw-normal fs-5 pe-3 mb-0">Learn how you can defend abortion access and say #BansOffOurBodies.</p>
        </div>
        <div class="col-md-6 text-end my-auto">
          <a href=""><button type="button" class="btn btn-light px-5 py-3 rounded-pill fw-bold">Learn More</button></a>
        </div>
      </div>
    </div>
  </section>

  <section class="py-5" id="" style="background:#f7f6f4; color:#333740">
    <div class="container">
      <div class="row">
        <div class="col-md-4">
          <div class="card" style="height:376px">
            <img src="img/img_7563.jpg__400x225_q80_crop_subsampling-2.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title pb-3">Is abortion legal in your area?</h5>
              
              <a href="#" class="btn btn-primary rounded-pill px-5">Find Out</a>
            </div>
          </div>
        </div>
        <div class="col-md-4">
        <div class="card" style="height:376px">
            <img src="img/sexual_harassment_org_photo.jpg__400x225_q80_crop_subsampling-2.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title pb-3">Make a gift to support Abortion Help.</h5>
              
              <a href="#" class="btn btn-primary rounded-pill px-5">Give Now</a>
            </div>
          </div>
        </div>
        <div class="col-md-4">
        <div class="card" style="height:376px">
            <img src="img/ppol_spot_on_homepage_kb.jpg__400x225_q80_crop_subsampling-2.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title pb-3">Use our app to track your period and birth control.</h5>
              
              <a href="#" class="btn btn-primary rounded-pill px-5">Try Now</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="py-5" id="" style="background:#ec008c; color:#fff">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <h2 class="fw-bolder mb-2">Check out our new toolkit on safer sex, STI testing, and stigma.</h2>
        </div>
        <div class="col-md-6 text-end my-auto">
          <a href=""><button type="button" class="btn btn-light px-5 py-3 rounded-pill fw-bold">Get the facts</button></a>
        </div>
      </div>
    </div>
  </section>

  <section class="py-5 email_alert" id="" style="background:#00286e; color:#fff">
    <div class="container">
      <div class="row">
        <div class="col-md-6 my-auto">
          <h1 class="fw-bolder mb-2">Sign Up for Email Alerts</h1>

          <p class="fw-normal fs-5 pe-5 mb-0">Join our network and be the first to take action in the fight to protect
            reproductive rights.</p>
        </div>
        <div class="col-md-6 text-start my-auto">
          <form action="" method="post" class="px-5" name="">
            <div class="mb-3">
              <label for="exampleInputEmail1" class="form-label">Email address</label>
              <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">

            </div>
            <div class="mb-3">
              <label for="exampleInputPassword1" class="form-label">Password</label>
              <input type="password" class="form-control" id="exampleInputPassword1">
            </div>
            <div id="" class="mb-3 pe-5 fw-light">I agree to receive email updates from Abortion Help. I may unsubscribe
              at any time.</div>
            <button type="submit" class="btn btn-info rounded-pill px-5">Subscribe</button>
          </form>
        </div>
      </div>
    </div>
  </section>

  
<?php
  include "footer.php";
?>