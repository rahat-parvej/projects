<?php
  
    Include "dbcon/dbcon.php";
    $cont=0;
    $d=mktime( 0,0 ,0 ,date('m'), date('d'), date('y')-1);
    $date= date("Y-m-d", $d);
    $sql = 'SELECT * FROM `abortion_data` WHERE 1';
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $datedata= strtotime($row['Date']);
        $ddata=date('Y-m-d', $datedata);
        //echo $ddata."<br>";
        if($ddata>$date)
        $cont++;
        
    } echo $cont;
    } else {
        
    }
    
    
?>