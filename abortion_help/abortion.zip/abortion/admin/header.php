<!doctype html>
<html class="no-js" lang="">

<head>
  <meta charset="utf-8">
  <title>Abortion Statistic</title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <meta property="og:title" content="">
  <meta property="og:type" content="">
  <meta property="og:url" content="">
  <meta property="og:image" content="">

  <link rel="manifest" href="site.webmanifest">
  <link rel="apple-touch-icon" href="icon.png">
  <!-- Place favicon.ico in the root directory -->
  <link rel="shortcut icon" href="../mother.ico" type="image/x-icon">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Indie+Flower&display=swap" rel="stylesheet">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Nosifer&display=swap" rel="stylesheet">
    <!-- Google fonts - Roboto -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700">
    <!-- Choices CSS-->
    <link rel="stylesheet" href="vendor/choices.js/public/assets/styles/choices.min.css">
    <!-- Custom Scrollbar-->
    <link rel="stylesheet" href="vendor/overlayscrollbars/css/OverlayScrollbars.min.css">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="css/custom.css">

    <link rel="stylesheet" href="../css/fontawesome.css">
    
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
  </head>
  <body>
      <!-- Side Navbar -->
      <?php
        
        $message = mysqli_query($conn, "SELECT COUNT(message) FROM `questions` WHERE answer=''");
        $messagecount = mysqli_fetch_assoc($message);
      ?>
    <nav class="side-navbar">
          <!-- Sidebar Header    -->
        <div class="sidebar-header d-flex align-items-center justify-content-center p-3 mb-3">
              <!-- User Info-->
            <div class="sidenav-header-inner text-center">
                <img class="img-fluid rounded-circle avatar mb-3" src="img/personal-security.png" alt="person">
                <h2 class="h5 text-white text-uppercase mb-0">Admin</h2>
                <p class="text-sm mb-0 text-muted"></p>
            </div>
              <!-- Small Brand information, appears on minimized sidebar-->
            <a class="brand-small text-center" href="index.php">
                  <p class="h3 m-0">Admin</p>
            </a>
        </div>
          <!-- Sidebar Navigation Menus-->
        <span class="text-uppercase text-gray-500 text-sm fw-bold letter-spacing-0 mx-lg-2 heading">Main</span>
        <?php $curPageName = substr($_SERVER["SCRIPT_NAME"],strrpos($_SERVER["SCRIPT_NAME"],"/")+1); ?>

        <ul class="list-unstyled">
              <li class="sidebar-item <?php if($curPageName=="index.php"){echo "active";} ?>">
                <a class="sidebar-link" href="index.php"> <svg class="svg-icon svg-icon-sm svg-icon-heavy me-xl-2"> <use xlink:href="#real-estate-1"> </use> </svg>Home </a>
              </li>
              
              <li class="sidebar-item <?php if($curPageName=="message.php"){echo "active";} ?>">
                <a class="sidebar-link" href="message.php"> <i class="fa-solid fa-message svg-icon svg-icon-sm svg-icon-heavy me-xl-2"></i>Message <div class="badge bg-danger"><?php echo $messagecount['COUNT(message)'];?> New</div></a>
              </li>
              <li class="sidebar-item <?php if($curPageName=="hospitals.php"){echo "active";} ?>"> 
                <a class="sidebar-link" href="hospitals.php"> <svg class="svg-icon svg-icon-xs svg-icon-heavy me-xl-2"> <use xlink:href="#chart-1"> </use> </svg>Hospitals Data</a>
              </li>
        </ul>
        <!-- <span class="text-uppercase text-gray-500 text-sm fw-bold letter-spacing-0 mx-lg-2 heading">Second menu</span> -->

        
    </nav>