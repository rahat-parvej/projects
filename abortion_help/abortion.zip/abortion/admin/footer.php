
  <!-- <section class=" text-white footer" id="" style="background:#000 ">
    <div class="container">
      <div class="row py-4">
        <div class="col-md-6 my-auto">
          <a class="footer-logo text-decoration-none" href="index.php"
            style="font-family: 'Indie Flower', cursive;font-size: 35px; font-weight: 800;"><span class="text-danger"
              style="font-family: 'Nosifer', cursive;">Abortion</span> Help</a>
              <ul class="pt-4 social">
                <li><a href="" target="_blank" rel="noopener noreferrer"><i class="fa-brands fa-facebook"></i></a></li>
                <li><a href="" target="_blank" rel="noopener noreferrer"><i class="fa-brands fa-twitter-square"></i></a></li>
                <li><a href="" target="_blank" rel="noopener noreferrer"><i class="fa-solid fa-square-envelope"></i></a></li>
              </ul>
        </div>
        <div class="col-md-6">
          <p>Abortion Help delivers vital reproductive health care, sex education, and information to millions of people
            worldwide.</p>
            <h5>Usefull Links</h5>
          <ul>
            <li><a href="http://">Abortion</a></li>
            <li><a href="http://">About Us</a></li>
            <li><a href="http://">Contact Us</a></li>
            <li><a href="http://">Hospital List</a></li>
            <li><a href="http://">About Us</a></li>
          </ul>
        </div>
      </div>
      <div class="row border-top pt-3 pb-5 text-center">
        
        <?php include "../developers.php" ?>
        
      </div>
    </div>
  </section> -->

  
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/just-validate/js/just-validate.min.js"></script>
    <script src="vendor/choices.js/public/assets/scripts/choices.min.js"></script>
    <script src="vendor/overlayscrollbars/js/OverlayScrollbars.min.js"></script>
    <script src="js/charts-home.js"></script>
    <!-- Main File-->
    <script src="js/front.js"></script>
    <script>
      // ------------------------------------------------------- //
      //   Inject SVG Sprite - 
      //   see more here 
      //   https://css-tricks.com/ajaxing-svg-sprite/
      // ------------------------------------------------------ //
      function injectSvgSprite(path) {
      
          var ajax = new XMLHttpRequest();
          ajax.open("GET", path, true);
          ajax.send();
          ajax.onload = function(e) {
          var div = document.createElement("div");
          div.className = 'd-none';
          div.innerHTML = ajax.responseText;
          document.body.insertBefore(div, document.body.childNodes[0]);
          }
      }
      // this is set to BootstrapTemple website as you cannot 
      // inject local SVG sprite (using only 'icons/orion-svg-sprite.svg' path)
      // while using file:// protocol
      // pls don't forget to change to your domain :)
      injectSvgSprite('https://bootstraptemple.com/files/icons/orion-svg-sprite.svg'); 
      
      
    </script>
    <!-- FontAwesome CSS - loading as last, so it doesn't block rendering-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
  </body>
</html>