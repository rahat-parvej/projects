<?php 
    //print_r($_POST);
    if ($_SERVER["REQUEST_METHOD"] == "POST"){
        $replay=filter_var($_POST['replay'], FILTER_SANITIZE_STRING);
        $id=filter_var ( $_POST['messageid'], FILTER_SANITIZE_NUMBER_INT);
        $id=filter_var ( $id, FILTER_VALIDATE_INT);
        echo $id;
        include "../dbcon/dbcon.php";
        $sql = "UPDATE `questions` SET `answer`='$replay',`ans_time`=NOW() WHERE id='$id'";

        if ($conn->query($sql) === TRUE) {
            
            $dataset = mysqli_query($conn, "SELECT * FROM `questions` WHERE id='$id'");
            $data = mysqli_fetch_assoc($dataset);
            print_r($data);
            require '../phpmailer/PHPMailerAutoload.php';
            $mail = new PHPMailer;
            $sender_email = 'rahatparvej2@gmail.com';
            $sender_pass = '11221234121';
    
            $receiver = $data['email'];
            // $mail->isSMTP(); // for localhost use enable this line otherwise don't use it
            $mail->Host = 'smtp.gmail.com';
            $mail->Port = 465;
            $mail->SMTPAuth = true;
            $mail->SMTPSecure = 'tls';
    
            $mail->Username = $sender_email; // Sender Email Id
            $mail->Password = $sender_pass; // password of gmail
    
            $mail->setFrom($sender_email,'Abortion Help');
    
            $mail->addAddress($receiver); // Receiver Email Address
            $mail->addReplyTo($sender_email);
    
            $mail->isHTML(true);
            $mail->Subject = "Replay Of your Message";
            $mail->Body = '<h5>Dear Sir, <br>Here is the response of your message. <br><b>Your message Were:</b> '.$data['message'].'<br><b>Our replay is: </b>'.$replay.'<br>Best regards,<br><b>Abortion Help</b></h5>';
            if($mail->send())
            {
                $mail->ClearAddresses();
                $mail->clearReplyTos();
                // mail_sent = 1 kore dilam er mane mail sent hoyse.
                $mail_sent = 1;
            }
            if($mail_sent==1){
                echo "<script>alert('Replay sent');window.location.replace('message.php');</script>";
            }
        } else {
            echo "Error updating record: " . $conn->error;
        }

        $conn->close();
    }

?>