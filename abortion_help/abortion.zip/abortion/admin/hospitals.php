<?php 
    session_start();
    //echo $_SESSION['Org_Code'];
    if($_SESSION['Org_Code']=='admin'){
        include "../dbcon/dbcon.php";
        include "header.php";
        ?>
    <div class="page">
      <!-- navbar-->
      <header class="header sticky-top">
        <nav class="navbar">
            <div class="container-fluid">
                <div class="d-flex align-items-center justify-content-between w-100">
                    <div class="d-flex align-items-center">
                        <a class="menu-btn d-flex align-items-center justify-content-center p-2 bg-gray-900 me-2" id="toggle-btn" href="#"><svg class="svg-icon svg-icon-sm svg-icon-heavy text-white"> <use xlink:href="#menu-1"> </use> </svg></a>
                        <div class="brand-text d-none d-md-inline-block text-uppercase letter-spacing-0">
                            <a class="navbar-brand" href="index.php" style="font-family: 'Indie Flower', cursive;font-size: 25px; font-weight: 800;"><span class="text-danger" style="font-family: 'Nosifer', cursive;">Abortion</span> Help</a>
                        </div>
                        
                    </div>
                  <ul class="nav-menu mb-0 list-unstyled d-flex flex-md-row align-items-md-center">
                      <!-- Log out-->
                        <li class="nav-item">
                            <a class="nav-link text-white text-sm ps-0" href="../logout.php"> 
                                <span class="d-none d-sm-inline-block">Logout</span>
                                <svg class="svg-icon svg-icon-xs svg-icon-heavy"> <use xlink:href="#security-1"> </use> </svg>
                            </a>
                        </li>
                  </ul>
              </div>
          </div>
        </nav>
      </header>

      <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h4 class="text-center border-bottom pt-5">Name of Hospitals listed</h4>
                <form>
                    <div class="mb-3">
                        <!-- <label for="" class="form-label">Email address</label> -->
                        <input type="text" class="form-control" id="myInput" onkeyup="myFunction()" aria-describedby="" placeholder="Search With Name">
                        
                    </div>
                    
                </form>
                <table class="table" id="myTable">
                    <thead>
                        <tr>
                            <th scope="col">Name</th>
                            <th scope="col">Type</th>
                            <th scope="col">District</th>
                            <th scope="col">Contact</th>
                            <th scope="col">Number of Data</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $sqlhos1 = "SELECT * FROM `hospital_list` ORDER BY District";
                            $resulthos1 = $conn->query($sqlhos1);
                            
                            if ($resulthos1->num_rows > 0) {
                              // output data of each row
                              while($rowhos1 = $resulthos1->fetch_assoc()) {
                                ?><tr>
                                    <td><?php echo $rowhos1['Name'];?></td>
                                    <td><?php echo $rowhos1['Org_Type'];?></td>
                                    <td><?php echo $rowhos1['District'];?></td>
                                    <td><a href="tel:+<?php echo $rowhos1['Mobile_Phones'];?>" class="text-black"><?php echo $rowhos1['Mobile_Phones'];?></a><br><?php echo $rowhos1['Land_Phones'];?></td>
                                    <td>
                                        <?php
                                            $namehos=$rowhos1['Name'];
                                            $data="SELECT COUNT(Date) FROM `abortion_data` WHERE Name_of_Hospital='$namehos'";
                                            $result = mysqli_query($conn, $data);
                                            $row = mysqli_fetch_assoc($result);
                                            echo $row['COUNT(Date)'];
                                        ?>
                                    </td>
                                </tr><?php
                              }
                            } else {
                              echo "0 results";
                            }
                            $conn->close();
                        ?>
                    </tbody>
                </table>
                <script>
                    function myFunction() {
                        var input, filter, table, tr, td, i, txtValue;
                        input = document.getElementById("myInput");
                        filter = input.value.toUpperCase();
                        table = document.getElementById("myTable");
                        tr = table.getElementsByTagName("tr");
                        for (i = 0; i < tr.length; i++) {
                            td = tr[i].getElementsByTagName("td")[0];
                            if (td) {
                                txtValue = td.textContent || td.innerText;
                                if (txtValue.toUpperCase().indexOf(filter) > -1) {
                                    tr[i].style.display = "";
                                } else {
                                    tr[i].style.display = "none";
                                }
                            }       
                        }
                    }
                </script>
            </div>
        </div>
      </div>

      </div>
        <?php
    }else{
        header("Location: ../logout.php");
        exit();
    }
?>

<?php include "footer.php" ?>