<?php 
    session_start();
    //echo $_SESSION['Org_Code'];
    if($_SESSION['Org_Code']=='admin'){
        include "../dbcon/dbcon.php";
        include "header.php";
        ?>
    <div class="page">
      <!-- navbar-->
      <header class="header sticky-top">
        <nav class="navbar">
            <div class="container-fluid">
                <div class="d-flex align-items-center justify-content-between w-100">
                    <div class="d-flex align-items-center">
                        <a class="menu-btn d-flex align-items-center justify-content-center p-2 bg-gray-900 me-2" id="toggle-btn" href="#"><svg class="svg-icon svg-icon-sm svg-icon-heavy text-white"> <use xlink:href="#menu-1"> </use> </svg></a>
                        <div class="brand-text d-none d-md-inline-block text-uppercase letter-spacing-0">
                            <a class="navbar-brand" href="index.php" style="font-family: 'Indie Flower', cursive;font-size: 25px; font-weight: 800;"><span class="text-danger" style="font-family: 'Nosifer', cursive;">Abortion</span> Help</a>
                        </div>
                        
                    </div>
                  <ul class="nav-menu mb-0 list-unstyled d-flex flex-md-row align-items-md-center">
                      <!-- Log out-->
                        <li class="nav-item">
                            <a class="nav-link text-white text-sm ps-0" href="../logout.php"> 
                                <span class="d-none d-sm-inline-block">Logout</span>
                                <svg class="svg-icon svg-icon-xs svg-icon-heavy"> <use xlink:href="#security-1"> </use> </svg>
                            </a>
                        </li>
                  </ul>
              </div>
          </div>
        </nav>
      </header>
      
      <div class="container">
        <div class="row">
            <div class="col-md-12">
                <p id="customer" style=""class="text-justify px-5 bg-light pt-5">
                    From here you can manage all of core settings. Such as:
                    
                </p>
                <ol class="text-justify px-5 bg-light">
                    <li>Troubleshooting and providing technical support to employees</li>
                    <li>Creating and managing system permissions and user accounts</li>
                    <li>Performing regular security tests and security monitoring</li>
                </ol>
                <div class="row">
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        <div class="card mx-auto" style="width:18rem">
                            <div class="card-body text-center">
                                <h5 class="card-title">Hospital Listed</h5>
                                <p class="card-text fs-1 fw-bold">
                                    <?php
                                        
                                        $result11x = mysqli_query($conn, "SELECT COUNT(Org_Code) FROM `hospital_list` WHERE 1");
                                        $listed_hospital = mysqli_fetch_assoc($result11x);
                                        echo $listed_hospital['COUNT(Org_Code)'];
                                    ?>
                                </p>
                                <a href="hospitals.php" class="btn btn-primary">See Data</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="card" style="width:18rem">
                            <div class="card-body text-center">
                                <h5 class="card-title">Hospital regestered</h5>
                                <p class="card-text fs-1 fw-bold">
                                    <?php
                                        
                                        $result10x = mysqli_query($conn, "SELECT COUNT(Org_Code) FROM `user` WHERE 1");
                                        $reg_hospital = mysqli_fetch_assoc($result10x);
                                        echo $reg_hospital['COUNT(Org_Code)']-1;
                                    ?>
                                </p><br><br>
                                <!-- <a href="#" class="btn btn-primary" disabled></a> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </div>
      
    </div>
        <?php
    }else{
        header("Location: ../logout.php");
        exit();
    }
?>

<?php include "footer.php" ?>