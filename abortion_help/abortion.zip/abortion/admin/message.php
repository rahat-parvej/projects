<?php 
    session_start();
    //echo $_SESSION['Org_Code'];
    if($_SESSION['Org_Code']=='admin'){
        include "../dbcon/dbcon.php";
        include "header.php";
        ?>
    <div class="page">
      <!-- navbar-->
      <header class="header sticky-top">
        <nav class="navbar">
            <div class="container-fluid">
                <div class="d-flex align-items-center justify-content-between w-100">
                    <div class="d-flex align-items-center">
                        <a class="menu-btn d-flex align-items-center justify-content-center p-2 bg-gray-900 me-2" id="toggle-btn" href="#"><svg class="svg-icon svg-icon-sm svg-icon-heavy text-white"> <use xlink:href="#menu-1"> </use> </svg></a>
                        <div class="brand-text d-none d-md-inline-block text-uppercase letter-spacing-0">
                            <a class="navbar-brand" href="index.php" style="font-family: 'Indie Flower', cursive;font-size: 25px; font-weight: 800;"><span class="text-danger" style="font-family: 'Nosifer', cursive;">Abortion</span> Help</a>
                        </div>
                        
                    </div>
                  <ul class="nav-menu mb-0 list-unstyled d-flex flex-md-row align-items-md-center">
                      <!-- Log out-->
                        <li class="nav-item">
                            <a class="nav-link text-white text-sm ps-0" href="../logout.php"> 
                                <span class="d-none d-sm-inline-block">Logout</span>
                                <svg class="svg-icon svg-icon-xs svg-icon-heavy"> <use xlink:href="#security-1"> </use> </svg>
                            </a>
                        </li>
                  </ul>
              </div>
          </div>
        </nav>
      </header>
      
        <div class="container">
            <div class="row">
                <div class="col-md-12 pt-5">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">Unread Messages</h5>
                                    <?php 
                                        $sql1="SELECT * FROM `questions` WHERE answer=''";
                                        $result1 = $conn->query($sql1);

                                        if ($result1->num_rows > 0) {
                                        // output data of each row
                                        while($row1 = $result1->fetch_assoc()) {
                                            ?>
                                            <div class="card-text border p-3 rounded  mb-3"><?php //print_r($row1); ?>
                                                <span><b>Name:</b> <?php echo $row1['name'];?></span>
                                                <span class="float-end"><b>Email:</b> <?php echo $row1['email'];?></span><br>
                                                <span><b>Subject:</b> <?php if($row1['subject']!=""){echo $row1['subject'];}else{echo"N/A";}?></span><br>
                                                <span><b>Message: </b> <?php echo $row1['message'];?></span><br>
                                                <span><b>Time of Post:</b> <?php echo date_format(date_create($row1['ask_time']),"Y-m-d h:i") ;?></span><br>
                                                <form action="replay.php" method="post">
                                                    <div class="row g-2">
                                                        <div class="col-md-9">
                                                            <div class="form-floating">
                                                                <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea2" style="height: 100px" name="replay" required></textarea>
                                                                <label for="floatingTextarea2">Comments</label>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-3 m-auto">
                                                            <button type="submit" name="messageid" class="btn btn-primary" value="<?php echo $row1['id']; ?>">Reply</button>
                                                        </div>
                                                    </div>
                                                    </form>
                                        </div>
                                            <?php
                                        }
                                        } else {
                                        echo "0 Unread Message";
                                        }
                                    
                                    ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">Recent Replays</h5>
                                    <?php 
                                        $sql1="SELECT * FROM `questions` WHERE answer!='' LIMIT 5";
                                        $result1 = $conn->query($sql1);

                                        if ($result1->num_rows > 0) {
                                        // output data of each row
                                        while($row1 = $result1->fetch_assoc()) {
                                            ?>
                                            <div class="card-text border p-3 rounded  mb-3"><?php //print_r($row1); ?>
                                                <span><b>Name:</b> <?php echo $row1['name'];?></span>
                                                <span class="float-end"><b>Email:</b> <?php echo $row1['email'];?></span><br>
                                                <span><b>Subject:</b> <?php if($row1['subject']!=""){echo $row1['subject'];}else{echo"N/A";}?></span><br>
                                                <span><b>Message: </b> <?php echo $row1['message'];?></span><br>
                                                <span><b>Time of Post:</b> <?php echo date_format(date_create($row1['ask_time']),"Y-m-d h:i") ;?></span><br>
                                                <span class="border d-block px-3 py-2"><b>Replay:</b> <?php echo $row1['answer'];?><br><b>At:</b><?php echo date_format(date_create($row1['ans_time']),"Y-m-d h:i") ;?></span></span>
                                        </div>
                                            <?php
                                        }
                                        } else {
                                        echo "0 recent replays";
                                        }
                                    
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      
    </div>
        <?php
    }else{
        header("Location: ../logout.php");
        exit();
    }
?>

<?php include "footer.php" ?>