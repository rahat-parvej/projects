<section class="learnhomebanner py-4" id="" style="/*margin-top:-25px*/">
    <div class="container pt-5">
        <div class="row pt-5">
            <div class="col-md-6 col-sm-12 pt-5 text-white ps-5">
                <h2 class="pt-5 fw-bold ps-3 fs-1">Get the Facts on<br> Sexual Health</h2>
            </div>
            <div class="col-md-6 text-white ps-5">
                <p class="pt-5 fw-bolder ps-5 fs-6 text-end">
                    Everything you need to know, from birth control to <br class="d-none d-sm-block"> healthy relationships, identity, and more.
                </p>
            </div>
        </div>
    </div>
</section>

<section class="bg-light py-5" id="" style="">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="text-center fs-3 mb-3">FEATURED CATEGORIES</h1>
                <div class="row">
                    <div class="col-md-3 my-auto">
                        <div class="list-group">
                            <a href="abortion" type="button" class="list-group-item list-group-item-action btn btn-outline-dark">Abortion Pill</a>
                            <a href="" type="button" class="list-group-item list-group-item-action btn btn-outline-dark">Ask The Experts</a>
                            <a href="" type="button" class="list-group-item list-group-item-action btn btn-outline-dark">Birth Control</a>
                        </div>
                    </div>
                    <div class="col-md-3 my-auto">
                        <div class="list-group">
                            <a href="cancer.html" type="button" class="list-group-item list-group-item-action btn btn-outline-dark">Cancer</a>
                            <a href="" type="button" class="list-group-item list-group-item-action btn btn-outline-dark">Emergency Contraception</a>
                            <a href="" type="button" class="list-group-item list-group-item-action btn btn-outline-dark">Gender Identity</a>
                        </div>
                    </div>
                    <div class="col-md-3 my-auto">
                        <div class="list-group">
                            <a href="" type="button" class="list-group-item list-group-item-action btn btn-outline-dark">Health and Wellness</a>
                            <a href="" type="button" class="list-group-item list-group-item-action btn btn-outline-dark">Pregnancy</a>
                            <a href="" type="button" class="list-group-item list-group-item-action btn btn-outline-dark">Sex and Relationships</a>
                        </div>
                    </div>
                    <div class="col-md-3 my-auto">
                        <div class="list-group">
                            <a href="" type="button" class="list-group-item list-group-item-action btn btn-outline-dark">Sexual Orientation</a>
                            <a href="" type="button" class="list-group-item list-group-item-action btn btn-outline-dark">Sexually Transmitted Infections (STDs)</a>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="bg-danger py-5 text-light" id="" style="">
    <div class="container">
        <div class="row">
            <div class="col-md-6 text-center mb-2" style="border-right:2px solid #fff">
                <i class="fa-solid fa-question border border-white p-4 bg-light fw-bold fs-3 rounded mb-3 text-dark"></i>
                <h3>For Teens</h3>
                <p>Questions about sex, <br> your body, or relationships? <br> We’ve got you. Here’s your ultimate guide <br> to getting through high school and beyond.</p>
                <a href="" type="button" class="btn btn-outline-light text-uppercase px-5 rounded-pill text-decoration-none">Learn More</a>
            </div>
            <div class="col-md-6 text-center" style="border-left:2px solid #fff">
                <i class="fa-solid fa-user-group border border-white p-4 bg-light fw-bold fs-3 rounded mb-3 text-dark"></i>
                <h3>For Parents</h3>
                <p>From talking about sex and <br> relationships to online bullying <br> to supporting your LGBT kid: how to <br> guide your children into making healthy decisions.</p>
                
                <a href="" type="button" class="btn btn-outline-light text-uppercase px-5 rounded-pill text-decoration-none">Learn More</a>
            </div>
        </div>
    </div>
</section>


<section class="" id="" style="">
    <div class="card">
        <img src="../img/educators_handbook.jpg__1200x675_q75_crop_subsampling-2.jpg" class="card-img" alt="..."
            height="640">
        <div class="card-img-overlay  container">
            <div class="row">
                <div class="col-md-7 d-none d-sm-block"></div>
                <div class="col-md-5 text-dark pt-5">
                    <h5 class="card-title fw-bold fs-2">For Educators</h5>
                    <p class="card-text fw-bolder">Sex education can be a challenging subject for students and teachers alike. Our tools and resources help you give your students what they need to make smart, healthy decisions.</p>
                    <a href="" type="button" class="btn btn-primary text-uppercase btn-lg rounded-pill text-decoration-none">Learn More</a>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="bg-white" id="" style="">
    <div class="container py-5">
        <div class="row">
            <div class="col-md-6">
                <h3 class="fw-bold">STDs</h3>
                <p class="fs-4 py-2">STDs are common infections that are passed through sexual contact. Many STDs are no big deal, and can be treated easily. But sometimes STDs can be dangerous. Luckily, it’s easy to get tested. Here’s how you can prevent getting or passing on an STD. Take the first step to a healthier, safer sex life.</p>
                <a href="" type="button" class="btn btn-primary text-uppercase btn-lg rounded-pill text-decoration-none">Get the facts</a>
            </div>
            <div class="col-md-6"></div>
        </div>
    </div>
</section>
<section class="" id="" style="">
    <div class="card">
        <img src="../img/emergency_contraception-1920x1080.jpg__1200x675_q75_crop_subsampling-2.jpg" class="card-img" alt="..."
            height="640">
        <div class="card-img-overlay  container">
            <div class="row">
                <div class="col-md-7 d-none d-sm-block"></div>
                <div class="col-md-5 text-dark pt-5">
                    <h5 class="card-title fw-bolder fs-2">Emergency Contraception</h5>
                    <p class="card-text fw-bold fs-5">Emergency contraception (AKA the morning-after pill) is a safe and effective way to prevent pregnancy up to 5 days after unprotected sex. Here’s how to figure out which kind of emergency contraception is right for you, how to get it, and what to expect.</p>
                    <a href="" type="button" class="btn btn-primary text-uppercase btn-lg rounded-pill text-decoration-none">Learn More</a>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="bg-white" id="" style="">
    <div class="container py-5">
        <div class="row">
            <div class="col-md-6">
                <h3 class="fw-bold">Pregnancy</h3>
                <p class="fs-4 py-2">Whether you want to find out if you could be pregnant, learn about having a healthy pregnancy, explore your options, or just want to know how the whole thing works, we’ve got the facts.</p>
                <a href="" type="button" class="btn btn-primary text-uppercase btn-lg rounded-pill text-decoration-none">Get the facts</a>
            </div>
            <div class="col-md-6 my-auto">
                <img src="../img/20170308_pregnancy_copy.jpg__800x600_q75_subsampling-2.jpg" alt="" srcset="" class="img-fluid">
            </div>
        </div>
    </div>
</section>

<section class="" id="" style="">
    <div class="card">
        <img src="abortion/img/abortion1.jpg__1200x675_q75_crop_subsampling-2.jpg" class="card-img" alt="..."
            height="640">
        <div class="card-img-overlay  container">
            <div class="row">
                <div class="col-md-7 d-none d-sm-block"></div>
                <div class="col-md-5 text-light pt-5 mt-auto">
                    <h5 class="card-title fw-bolder fs-2">Abortion</h5>
                    <p class="card-text fw-bold fs-5">Abortion is a safe and legal way to end a pregnancy. If you’re pregnant and thinking about abortion, you may have questions about your options. Only you can decide if abortion is right for you. Getting the facts can help.</p>
                    <a href="abortion/" type="button" class="btn btn-primary text-uppercase btn-lg rounded-pill text-decoration-none">Learn More</a>
                </div>
                
            </div>
        </div>
    </div>
</section>

<section class="bg-white" id="" style="">
    <div class="container py-5">
        <div class="row">
            <div class="col-md-6">
                <h3 class="fw-bold">Sexual Orientation and Gender</h3>
                <p class="fs-4 py-2">Sexual orientation and gender don’t define us — but they’re important parts of who we are and how we interact with the world around us. Whether you’re straight, gay, trans, cis, something else, or figuring it all out, we’ve got answers to some of the most common questions about gender and sexuality.</p>
                <a href="" type="button" class="btn btn-primary text-uppercase btn-lg rounded-pill text-decoration-none">Get the facts</a>
            </div>
            <div class="col-md-6 my-auto pt-3">
                <div class="container">
                    <div class="row mb-5">
                        <div class="col-md-6 col-6 text-center"><i class="fa-solid fa-transgender fs-1"></i></div>
                        <div class="col-md-6 col-6"><i class="fa-solid fa-venus-mars fs-1"></i></div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 col-6 text-center"><i class="fa-solid fa-mars-double fs-1"></i></div>
                        <div class="col-md-6 col-6"><i class="fa-solid fa-mars-and-venus fs-1"></i></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="" id="" style="">
    <div class="card">
        <img src="../img/pexels-asad-photo-maldives-1024960.jpg" class="card-img" alt="..."
            height="640">
        <div class="card-img-overlay  container">
            <div class="row">
                <div class="col-md-7 d-none d-sm-block"></div>
                <div class="col-md-5 text-dark pt-5 mt-auto">
                    <h5 class="card-title fw-bolder fs-2">Sex and Relationships</h5>
                    <p class="card-text fw-bold fs-5">Healthy relationships can bring joy and connection to our lives — and sex can play a major role. Find out what it takes to have a healthy, happy, and meaningful sex and love life.</p>
                    <a href="" type="button" class="btn btn-primary text-uppercase btn-lg rounded-pill text-decoration-none">Learn More</a>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="py-5" id="" style="background:#ec008c; color:#fff">
    <div class="container">
        <div class="row">
            <div class="col-md-6 d-none d-sm-block">
                
            </div>
            <div class="col-md-6 text-start my-auto">
                <h2 class="fw-bolder mb-2">Cancer</h2>
                <p class="card-text fs-5">Breast, gynecological, and testicular cancers affect millions of people in the U.S. every year. Early cancer screening saves lives. Learn about your risks and the testing and treatments available with us.</p>
                <a href="" type="button" class="btn btn-outline-light text-uppercase btn-lg rounded-pill text-decoration-none">Learn More</a>
            </div>
        </div>
    </div>
</section>

<section class="" id="" style="">
    <div class="card">
        <img src="../img/health_and_wellness1.jpg__1200x675_q75_crop_subsampling-2.jpg" class="card-img" alt="..."
            height="640">
        <div class="card-img-overlay  container">
            <div class="row">
                
                <div class="col-md-5 text-dark pt-5 mt-auto">
                    <h5 class="card-title fw-bolder fs-2">Sex and Relationships</h5>
                    <p class="card-text fw-bold fs-5">Healthy relationships can bring joy and connection to our lives — and sex can play a major role. Find out what it takes to have a healthy, happy, and meaningful sex and love life.</p>
                    <a href="" type="button" class="btn btn-primary text-uppercase btn-lg rounded-pill text-decoration-none">Learn More</a>
                </div><div class="col-md-7 d-none d-sm-block"></div>
            </div>
        </div>
    </div>
</section>

<section class="" id="" style=""></section>
