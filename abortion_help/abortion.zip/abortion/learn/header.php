<!doctype html>
<html class="no-js" lang="">

<head>
  <meta charset="utf-8">
  <title>Abortion Statistic</title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <meta property="og:title" content="">
  <meta property="og:type" content="">
  <meta property="og:url" content="">
  <meta property="og:image" content="">

  <link rel="manifest" href="site.webmanifest">
  <link rel="apple-touch-icon" href="icon.png">
  <!-- Place favicon.ico in the root directory -->
  <link rel="shortcut icon" href="../mother.ico" type="image/x-icon">

  <link rel="stylesheet" href="../css/normalize.css">
  <link rel="stylesheet" href="../css/main.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Indie+Flower&display=swap" rel="stylesheet">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Nosifer&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="../css/fontawesome.css">


  <meta name="theme-color" content="#fafafa">



  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
</head>

<body>
    <header>
        <div class="container-fluid px-0 " style="background:#00286e; color:#d5dce7 !important">
            <nav class="navbar navbar-expand-lg navbar-dark py-3">
                <div class="container">
                    <a class="navbar-brand" href="../index.php"
                        style="font-family: 'Indie Flower', cursive;font-size: 35px; font-weight: 800;"><span
                            class="text-danger" style="font-family: 'Nosifer', cursive;">Abortion</span> Help</a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                        data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                        aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
                            <li class="nav-item px-3 fs-5 text-light fw-bold"><a class="nav-link" aria-current="page" href="#">Learn</a></li>
                            <li class="nav-item px-3 fs-5 text-light fw-bold"><a class="nav-link" href="../statistic.php?filter=Age&district=select">Statistics</a></li>
                            <li class="nav-item px-3 fs-5 text-light fw-bold"><a class="nav-link" href="../">Contact Us</a></li>
                            <!-- <li class="nav-item"><a class="nav-link disabled">Login</a></li> -->
                            <li class="nav-item px-3 fs-5 text-light fw-bold dropdown"> 
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">Login</a>
                                
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink" style="min-width: 270px;">
                                    <form class="p-2 text-center" method="post" action="../login.php">
                                        <!-- <div class="mb-3">
                                            <input type="email" class="form-control" id="" aria-describedby="emailHelp" placeholder="Email Address"  data-bs-toggle="tooltip" title="Please Enter a valid email address" name="login_email" required>
                                        </div> -->
                                        <div class="form-floating mb-3">
                                            <input type="email" class="form-control" id="floatingInput" placeholder="name@example.com" aria-describedby="emailHelp" data-bs-toggle="tooltip" title="Please Enter a valid email address" name="login_email" required>
                                            <label for="floatingInput">Email address</label>
                                        </div>
                                        <!-- <div class="mb-3">
                                            <input type="password" class="form-control" id="" placeholder="Password" name="login_pass" minlength="4" required>
                                        </div> -->
                                        <div class="form-floating mb-3">
                                            <input type="password" class="form-control" id="floatingPassword" placeholder="Password" name="login_pass" minlength="4" required>
                                            <label for="floatingPassword">Password</label>
                                        </div>
                                        <button type="submit" class="btn btn-primary mb-3" name="login_btn" value="submit">Login</button>
                                        <p>New Hospital?&nbsp; &nbsp; <a href="../regestration.php" class="text-decoration-none">Register</a></p>
                                    </form>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>
    </header>
    
    
