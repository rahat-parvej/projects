<?php 
    include "header.php";
?>
    <?php
        if(!isset($_GET['page'])){
           include "learnhome.php";
        }else{
            $page=$_GET['page'];
            
            if($page='a'){
                include "";
            }
        }
    ?>

<?php 
    include "footer.php";
?>