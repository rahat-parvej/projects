<!doctype html>
<html class="no-js" lang="">

<head>
  <meta charset="utf-8">
  <title>Abortion Statistic</title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <meta property="og:title" content="">
  <meta property="og:type" content="">
  <meta property="og:url" content="">
  <meta property="og:image" content="">

  <link rel="manifest" href="site.webmanifest">
  <link rel="apple-touch-icon" href="icon.png">
  <!-- Place favicon.ico in the root directory -->
  <link rel="shortcut icon" href="../../mother.ico" type="image/x-icon">

  <link rel="stylesheet" href="../../css/normalize.css">
  <link rel="stylesheet" href="../../css/main.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Indie+Flower&display=swap" rel="stylesheet">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Nosifer&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="../../css/fontawesome.css">


  <meta name="theme-color" content="#fafafa">



  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
  <link rel="stylesheet" href="../css/learn_pages_minimal.627f18933524.css" />
</head>

<body>
    <header>
        <div class="container-fluid px-0" style="background:#00286e; color:#d5dce7 !important">
            <nav class="navbar navbar-expand-lg navbar-dark py-3">
                <div class="container">
                    <a class="navbar-brand" href="../../"
                        style="font-family: 'Indie Flower', cursive;font-size: 35px; font-weight: 800;"><span
                            class="text-danger" style="font-family: 'Nosifer', cursive;">Abortion</span> Help</a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                        data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                        aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                            <li class="nav-item px-3 fs-5 text-light fw-bold"><a class="nav-link" aria-current="page"
                                    href="../">Learn</a></li>
                            <li class="nav-item px-3 fs-5 text-light fw-bold"><a class="nav-link"
                                    href="../../statistic.php?filter=Age&district=select">Statistics</a></li>
                            <!-- <li class="nav-item"><a class="nav-link disabled">Login</a></li> -->
                            <li class="nav-item px-3 fs-5 text-light fw-bold dropdown"> 
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">Login</a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                    <form class="p-2 text-center" method="post" action="../../login.php">
                                        <div class="mb-3">
                                            <input type="email" class="form-control" id="" aria-describedby="emailHelp" placeholder="Email Address"  data-bs-toggle="tooltip" title="Please Enter a valid email address" name="login_email" required>
                                        </div>
                                        <div class="mb-3">
                                            <input type="password" class="form-control" id="" placeholder="Password" name="login_pass" minlength="4" required>
                                        </div>
                                        <button type="submit" class="btn btn-primary " name="login_btn" value="submit">Login</button>
                                    </form>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-12 d-none d-sm-block" style="margin-top: 20px;margin-bottom: -50px;">
                    <?php 
                        echo '<a href="../../">Home</a>';
                        $url= $_SERVER['REQUEST_URI'];
                        $position=explode("/",$url);
                        //print_r($position);
                        //echo $position[1];
                        foreach ($position as $value) {
                            if(preg_match("/page/", $value)){
                                $value=substr($value,6);
                            }
                            if($value==''){
                                
                            }else if($value=='abortion'){}else{echo "><span class='text-capitalize'>".$value ."</span>"; }
                             
                        }
                    ?>
                </div>
            </div>
        </div>  
    </header>
    
    
    
