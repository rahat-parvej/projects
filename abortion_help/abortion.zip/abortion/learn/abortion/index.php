<?php
  include "header.php";
  
  
?>
<?php
    if(!isset($_GET['page'])){
        ?>
  <div class="page-wrap">

    <main class="site-main two-column" id="site-main">

      <div class="breadcrumbs-wrapper">
        <nav class="breadcrumbs variable-height" aria-label="breadcrumbs" data-breadcrumb data-debug-label="Thu, 19 Jan 2023 15:45:59 +0000">
          <ul class="breadcrumbs-list">
            <li><a href="../../">Home</a></li>
            <li><a href="../">Learn</a></li>
            <li><span aria-label="current page: The Abortion Pill">The Abortion Pill</span></li>
          </ul>
        </nav>
      </div>
      <div class="page-upper pb-0">
        <div class="page-content" id="sticky-anchor">

          <header class="page-header">
            <h1 class="page-title">The Abortion Pill</h1>
          </header>
          <section class="section-nav" data-tile-name="In this section" data-component-name="topic page navigation" data-component-type="navigation">
            <div class="tile tile-expandable">
              <div class="tile-content has-icons" data-accordion data-allow-all-closed="true">
                <div class="accordion-item is-active" data-accordion-item>
                  <a href="#" class="accordion-title">In This Section</a>
                  <div class="accordion-content" data-tab-content>
                    <ul class="section-nav-list">
                      <li data-count="1"> <span>The Abortion Pill</span> </li>
                      <li data-count="2"> <a href="the-abortion-pill/how-does-the-abortion-pill-work.html" data-link>How does the abortion
                          pill work?</a> </li>
                      <li data-count="3"> <a href="the-abortion-pill/what-can-i-expect-after-i-take-the-abortion-pill" data-link>What can
                          I expect after I take the abortion pill?</a> </li>
                      <li data-count="4"> <a href="the-abortion-pill/how-do-i-use-abortion-pill" data-link>How do I use the abortion
                          pill?</a> </li>
                    </ul>
                    <ul class="section-nav-list">
                      <li data-count="5"> <a href="the-abortion-pill/how-safe-is-the-abortion-pill" data-link>How safe is the abortion pill?</a> </li>
                      <li data-count="6"><a href="the-abortion-pill/how-do-i-get-the-abortion-pill.html" data-link>How do I get the abortion pill?</a></li>
                      <li data-count="7"><a href="the-abortion-pill/how-much-does-abortion-pill-cost.html" data-link>How much does the abortion pill cost?</a></li>
                    </ul>


                  </div>
                </div>
              </div>
            </div>
          </section>
          <iframe width="660" height="400" src="https://www.youtube-nocookie.com/embed/vehnqGqStIc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
          
          <div class="intro" data-component-name="intro text" data-component-type="text">
            <h2>What is the abortion pill?</h2>

            <p>Medication abortion — also called the abortion pill — is a safe and effective way to end an early
              pregnancy.  </p>
          </div>

          <h2>How does the abortion pill work?</h2>
          <p>“Abortion pill” is the common name for using two different medicines to end a pregnancy: mifepristone and
            misoprostol.</p>
          <p>First, you take a pill called mifepristone. Pregnancy needs a hormone called progesterone to grow normally.
            Mifepristone blocks your body’s own progesterone, stopping the pregnancy from growing.</p>
          <p>Then you take the second medicine, misoprostol, either right away or up to 48 hours later. This medicine
            causes cramping and bleeding to empty your <span class="has-tip" data-lang="en"
              data-lookup="763">uterus</span>. It’s kind of like having a really heavy, crampy period, and the process
            is very similar to an early miscarriage. If you don’t have any bleeding within 24 hours after taking the
            second medicine, call your nurse or doctor.</p>
          <p>Your doctor or nurse will give you both medicines at the health center. When and where you’ll take them
            depends on state laws and your health center's policies. Your doctor or nurse will give<a id="effectiveness"
              name="effectiveness"></a> you detailed directions about where, when, and how to take the medicines. You
            may also get some antibiotics to prevent infection.</p>
          <h2>How effective is the abortion pill?</h2>
          <p>The abortion pill is very effective. The effectiveness depends on how far along you are in your pregnancy
            when you take the medicine.</p>
          <ul>
            <li>For people who are 8 weeks pregnant or less, it works about 94-98 out of 100 times.</li>
            <li>For people who are 8-9 weeks pregnant, it works about 94-96 out of 100 times.</li>
            <li>For people who are 9-10 weeks pregnant, it works about 91-93 out of 100 times. If you're given an extra
              dose of medicine, it works about 99 out of 100 times.</li>
            <li>For people who are 10-11 weeks pregnant, it works about 87 out of 100 times. If you're given an extra
              dose of medicine, it works about 98 out of 100 times.</li>
          </ul>
          <p>The abortion pill usually works, but if it doesn’t, you can take more medicine or have an <a
              href="in-clinic-abortion-procedures">in-clinic abortion</a> to complete the abortion.</p>
          <h2>When can I take the abortion pill?</h2>
          <p>Depending on where you live, you may be able to get a medication abortion up to 77 days (11 weeks) after
            the first day of your last period. If it has been 78 days or more since the first day of your last period,
            you can have an <a href="in-clinic-abortion-procedures">in-clinic abortion</a> to end your pregnancy.</p>
          <h2>Why do people choose the abortion pill?</h2>
          <p>Which kind of abortion you choose all depends on your personal preference and situation. With medication
            abortion, some people like that you don’t need to have a procedure in a doctor’s office. You can have your
            medication abortion at home or in another comfortable place that you choose. You get to decide who you want
            to be with during your abortion, or you can go it alone. Because medication abortion is similar to a
            miscarriage, many people feel like it’s more “natural” and less invasive.</p>
          <p><a id="abortionpillreversal" name="abortionpillreversal"></a>Your doctor, nurse, or health center staff can
            help you decide which kind of abortion is best for you.</p>
          <h2>More questions from patients:</h2>

          <div class="accordion" id="accordionExample">
            <div class="accordion-item">
              <h2 class="accordion-header" id="headingOne"><button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">Can the abortion pill be reversed after you have taken it?</button></h2>
              <div id="collapseOne" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                <div class="accordion-body">
                  <p>Here’s the deal: The “abortion pill” is the popular name for a safe and effective way to end an early pregnancy using a combination of two medicines: mifepristone and misoprostol. The first medicine (mifepristone) is given at a health center or your health care provider’s office. After  taking mifepristone, you take a second medication (misoprostol) at home 6-48 hours later. This causes cramping and bleeding and empties your uterus.</p>

                  <p>Claims about treatments that reverse the effects of medication abortion are out there, and a handful of states require doctors and nurses to tell their patients about them before they can provide abortion care. But these claims haven’t been proven in reliable medical studies — nor have they been tested for safety, effectiveness, or the likelihood of side effects — so experts like the American College of Obstetricians and Gynecologists reject these untested supposed treatments. </p>

                  <p>Studies on the abortion pill do show that if you take the first medicine but not the second, the abortion pill is less likely to work. So if you’ve begun the process of having an abortion using the abortion pill but are having second thoughts, contact the doctor or nurse you saw for the abortion right away to talk about your best next steps and what to expect.</p>
                </div>
              </div>
            </div>
            <div class="accordion-item">
              <h2 class="accordion-header" id="headingTwo">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">What is the RU-486 abortion pill?</button>
              </h2>
              <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo"
                data-bs-parent="#accordionExample">
                <div class="accordion-body">
                  <p>RU-486 is the former name of mifepristone — one of the medications that you take to have a medication abortion. RU-486 is now called "the abortion pill" or "Mifeprex" (the brand name for mifepristone).</p>

                  <p>RU-486 was developed in the 1980s. It's been safely used in Europe since 1987, and in the US since 2000.</p>

                  <p>RU-486 blocks a hormone that your body needs to continue a pregnancy. It works best when you use it with another medication called misoprostol, which causes bleeding to empty your uterus.</p>

                  <p>The RU-486 abortion pill is a safe and effective way to end an early pregnancy.</p>
                </div>
              </div>
            </div>
            <div class="accordion-item">
              <h2 class="accordion-header" id="headingThree">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                  What happens if I take the abortion pill after 11 weeks?
                </button>
              </h2>
              <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree"
                data-bs-parent="#accordionExample">
                <div class="accordion-body">
                  <p>The abortion pill is very effective, but it works less well when you’re more than 8 weeks pregnant. The effectiveness depends on how far along you are in your pregnancy and when you take the medicine. After 11 weeks, there’s a bigger chance of stronger bleeding or cramps. </p>
                  <p>You can make sure that your medication abortion worked by taking a <a href="https://www.nhs.uk/pregnancy/trying-for-a-baby/doing-a-pregnancy-test/">ultrasound</a>, or blood test. Your nurse or doctor will also walk you through everything you need to know during your medication abortion appointment.</p>
                </div>
              </div>
            </div>
          </div>
          
          <nav class="section-pagination" aria-label="Pagination" data-component-name="topic page navigation prev next" data-component-type="navigation">
            <a class="section-pagination-pager section-pagination-pager-next" href="the-abortion-pill/how-does-the-abortion-pill-work.html"><span class="section-pagination-pager-label">Next</span> <span class="section-pagination-pager-destination">How does the abortion pill work?</span></a>
          </nav>

          <div class="block swatch-bg-balance-gray" data-component-name="vote" data-component-type="vote">
            <div class="thumbs">
              <fieldset>
                <legend class="thumbs-question">Was this page helpful?</legend>
                <ul class="thumbs-group">
                  <li>
                    <label for="yes" class="thumbs-up" data-vote="up" data-show-positive-follow-up>
                      <span class="show-for-sr">Yes
                        <input type="radio" name="vote_result" id="positive_vote" value="Yes">
                      </span>
                    </label>
                  </li>
                  <li>
                    <label for="no" data-vote="down" class="thumbs-down" data-show-negative-follow-up>
                      <span class="show-for-sr">No
                        <input type="radio" name="vote_result" id="negative_vote" value="No">
                      </span>
                    </label>
                  </li>
                </ul>
              </fieldset>
              
            </div>
          </div>
        </div>

        <div class="page-sidebar">
          <div data-optional-promos id="sticky-top-anchor" class="sticky-top-anchor">
            <div class="theme-care-blue">
              <section id="promo-1528528" class="promo has-content theme-care-blue grid-container grid-x" data-promo-name="Abortion Clinics Near You" data-component-name="promotion" data-component-type="promo">
                <h3 class="promo-heading">Abortion Clinics Near You</h3>
                <div class="promo-content">
                  <p><strong>View Planned Parenthood health centers that provide abortion care and get the information
                      you need to schedule an appointment.</strong></p>
                  <p class="small">Your information is private and anonymous.</p>
                </div>
                <a class="button theme-white hollow" rel=" " href="../../#health_center" data-cmslink="true" data-cta-button-name="Find Abortion Services" data-interstitial-text="">Find Abortion Services</a>
              </section>
            </div>
          </div>
          
        </div>
        
        
      </div>
    </main><a href="#"><button type="button" class="btn btn-primary float-end m-3">Back to top</button></a>

    <div class="page-post-content">
      <section class="chatbot-desktop theme-deep-magenta" id="id_chatbot-banner-desktop" role="banner"
        data-section-name="Roo Chatbot" data-component-name="roo" data-component-type="chat">
        <div class="wrapper">
          <div class="logo-container"><img src="img/icon-bubble-white-cropped.webp" alt="" srcset="">          </div>
          <div class="body">
            <h3 class="chatbot-desktop-heading">Ask us anything. Seriously.</h3>
            <p class="chatbot-desktop-text">Between our trained sexual health educators or chat bot, we can answer your
              questions about your sexual health whenever you have them. And they are free and confidential.</p>
            <a class="button wide-small theme-white" target="_blank"
              href="https://roo.plannedparenthood.org/unifiedonboarding/intro?context=/learn/abortion/the-abortion-pill">
              CHAT NOW
            </a>
          </div>
        </div>
      </section>
    </div>
  </div> <!-- End .page-wrap -->
        <?php
    }else{
        $page=$_GET['page'];
        
        if($page='it-still-legal-me-get-abortion'){
            include "it-still-legal-me-get-abortion.php";
        }
    }
?>


<?php
  include "footer.php";
?>