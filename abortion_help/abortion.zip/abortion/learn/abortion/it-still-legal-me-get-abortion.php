<section class="pt-5 pb-4" id="" >
    <div class="container">
        <div class="row">
            <div class="col-md-12 pe-5 ">
                <h1 class="fw-bold pe-5 me-5">Abortion in Bangladesh is illegal under most situations: <span class="fw-bolder">What You need To Know</span> </h1>
                <div class="row">
                    <div class="col-md-9 col-sm-12">
                        <p class="" style="text-align:justify;">Historically, abortion has been prevalent, especially during the years following the Bangladesh Liberation War. For example, in 1972, the law allowed for abortion for those women who has been raped during the war. In 1976, the Bangladesh National Population Policy unsuccessfully attempted to legalize abortion in the first trimester. <br>In 2012, the Drug Administration for Bangladesh legalised the combination of mifepristone and misoprotol for medical abortion. So, <strong> We’re here to make sure you understand these new laws and how they may affect your options for getting a safe, legal abortion.</strong></p>
                    </div>
                </div>
            </div>
            <div class="col-md-12 pe-5 ">
                <h1 class="fw-bold pe-5 me-5">Where can I get an abortion?</h1>
                <div class="row">
                    <div class="col-md-9 col-sm-12">
                        <p class="" style="text-align:justify;">In Bangladesh, trained providers can only legally provide abortions if the woman’s life is in danger. MR can be performed by doctors and paramedics known as Family Welfare Visitors.MR and legal abortion services are provided for free at primary-, secondary-, and tertiary-level public health facilities; private family planning clinics; and certain NGOs. <br>
                        You can also find an abortion provider at <a href="https://www.mariestopes.org.bd/" target="_blank" rel="noopener noreferrer">Marie Stopes Bangladesh</a>. 
                    </p>
                    </div>
                </div>
                
            </div>

            <div class="col-md-12 pe-5 ">
                <h1 class="fw-bold pe-5 me-5">What is the cost of a safe abortion in Bangladesh?</h1>
                <div class="row">
                    <div class="col-md-9 col-sm-12">
                        <p class="" style="text-align:justify;">MR is available free of charge. Misoprostol, or a combination of Misoprostol and Mifepristone (indicated for menstrual regulation), can be bought from pharmacists as: <br>
                        <ul>
                            <li>Mifeston, at 175 BDT or 2 USD,</li>
                            <li>Terminix Table Kit, at 300 BDT or 3-4 USD, and</li>
                            <li>Cytomis (per pack), at 450 BDT or 5-6 USD.</li>
                        </ul>
                    </p>
                    </div>
                </div>
            </div>

            <div class="col-md-12 pe-5 ">
                <h1 class="fw-bold pe-5 me-5">Abortion LAWs in Bangladesh?</h1>
                <div class="row">
                    <div class="col-md-9 col-sm-12">
                        <p class="" style="text-align:justify;">
                            Abortion is only permitted to save the life of the woman. <br>
                            MR (menstruation regulation) is permitted up to 12 weeks of pregnancy. <br>
                            <strong><span class="text-danger"><a href="http://bdlaws.minlaw.gov.bd/act-11.html" target="_blank" rel="noopener noreferrer" class="text-decoration-none">Bangladesh Penal Code</a> </span></strong> (Act XLV, 1860), 6 October 1860. <br><br>
                            <b>Section 312.</b>   Whoever voluntarily causes a woman with child to miscarry shall, if such miscarriage be not caused in good faith for the purpose of saving the life of the pregnant woman, be punished with imprisonment of either description for a term which may extend to three years, or with fine, or with both; and, if the woman be quick with child, shall be punished with imprisonment of either description for a term which may extend to seven years, and shall also be liable to fine.  <br>

                            <big>Explanation—</big>A woman who causes herself to miscarry is within the meaning of this section.  <br><br>

                            <b>Section 313.</b>   Whoever commits the offence defined in the last preceding section without the consent of the woman, whether the woman is quick with child or not, shall be punished with transportation for life, or with imprisonment of either description for a term which may extend to ten years, and shall also be liable to fine. <br><br>

                            <b>Section 314.</b>   Whoever, with intent to cause the miscarriage of a woman with child, does any act which causes the death of such woman shall be punished with imprisonment of either description for a term which may extend to ten years, and shall also be liable to fine; and if the act is done without the consent of the woman, shall be punished either with transportation for life, or with the punishment above mentioned. <br>

                            <big>Explanation—</big>It is not essential to this offence that the offender should know that the act is likely to cause death. <br><br>

                            <b>Section 315.</b>   Whoever, before the birth of any child, does any act with the intention of thereby preventing that child from being born alive or causing it to die after its birth, and does by such act prevent that child from being born alive, or causes it to die after its birth, shall, if the act be not caused in good faith for the purpose of saving the life of the mother, be punished with imprisonment of either description for a term which may extend to ten years, or with fine, or with both. <br><br>

                            <b>Section 316.</b>   Whoever without lawful excuse does any act knowing that he is likely to cause death to a pregnant woman, and does by such act cause the death of a quick unborn child, shall be punished with imprisonment of either description for a term which may extend to ten years, and shall also be liable to <br>
                        </p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-12 pe-5 ">
                <h1 class="fw-bold pe-5 me-5">What are the different abortion services available in Bangladesh?</h1>
                <div class="row">
                    <div class="col-md-9 col-sm-12">
                        <p class="" style="text-align:justify;">Bangladesh provides both medical and in-clinic abortion services. A combination of two drugs, Mifepristone and Misoprostol, is used for a Medical Abortion (MA), and the only available in-clinic procedure is an MVA. <br>
                        <ul>
                            <li>Medical abortion: MR, using the combination of Misoprostol and Mifepristone, is permitted until nine weeks after a woman’s last menstrual period.</li>
                            <li>In-clinic abortion: MR through MVA is permitted until 10-12 weeks after a woman’s last menstrual period.</li>
                            
                        </ul>
                        Note: <br>Procedures after these timelines are considered abortion cases and will only be permitted according to the provisions contained in the Penal code of 1860.
                    </p>
                    </div>
                </div>
            </div>

            <div class="col-md-12 pe-5 ">
                <h1 class="fw-bold pe-5 me-5">Which abortion pills are available in Bangladesh?</h1>
                <div class="row">
                    <div class="col-md-9 col-sm-12">
                        <p class="" style="text-align:justify;">There are three types of abortion pills, under different brand names, available in Bangladesh: <br>
                        <ul>
                            <li>Mifepristone (Mifeprist, Mifetab, Mifecon, Mifeston, Mifegest, MIF, Mprix, Mifovent, Mediprist, and MTY),</li>
                            <li>Misoprostol (Miclofenac, Ultrafen-plus, Erdon Super, Misoclo, Misofen, Arthrofen, and Dix Extra).</li>
                            <li>Combination of misoprostol and mifepristone ( Cytomis, Terminex)</li>
                            <li>Mifepristone is a drug that blocks the hormone, progesterone, which is needed for a pregnancy to continue. Misoprostol is used after Mifepristone to encourage a complete medical abortion. Misoprostol can also be used on its own. You can find more information on Misoprostol and Mifepristone usage <a href="https://www.howtouseabortionpill.org/howto/" target="_blank" rel="noopener noreferrer" class="text-decoration-none">here.</a> </li>
                            
                        </ul>
                    </p>
                    </div>
                </div>
            </div>

            <div class="col-md-12 pe-5 ">
                <h1 class="fw-bold pe-5 me-5">What do the abortion pills look like in Bangladesh?</h1>
                <div class="row">
                    <div class="col-md-9 col-sm-12">
                        <p class="" style="text-align:justify;">Yes, abortion pills can be bought at registered pharmacies in Australia but only with a prescription from a doctor who has been approved to provide these medications. <br>
                        The most common brand name for abortion pills in Bangladesh is Cytomis Kit. This is what the Cytomis Kit abortion pills look like: <br>
                        <img src="../../img/cytomiskit.avif" alt="" srcset=""> 
                        Photo credit: <a href="http://www.inceptapharma.com/product-details.php?pid=587" target="_blank" rel="noopener noreferrer">http://www.inceptapharma.com/product-details.php?pid=587</a> <br>
                        This is what the Terminex abortion pills looks like:
                        <img src="../../img/terminex.avif" alt="" srcset=""> <br>
                        Photo credit: <a href="http://www.squarepharma.com.bd/product-details.php?pid=631" target="_blank" rel="noopener noreferrer">http://www.squarepharma.com.bd/product-details.php?pid=631</a> <br>
                        This is what the Mifeston abortion pills look like:
                            <img src="../../img/mifeston.avif" alt="" srcset=""> <br>
                    </p>
                    </div>
                </div>
            </div>
        </div>
    </div>

</section>