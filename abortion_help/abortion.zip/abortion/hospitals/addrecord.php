<?php
    session_start();
    if($_SESSION['email']=="" || $_SESSION['Org_Code']==""){
        header("Location: ../");
        exit();
    }else{
        include "../dbcon/dbcon.php";
        $org_code=$_SESSION['Org_Code'];
        $orgdata=mysqli_query($conn, "SELECT * FROM `hospital_list` WHERE Org_Code='$org_code'");
        $orginform=mysqli_fetch_assoc($orgdata);

        include "header.php";
        ?>
        <div class="container-fluid">
            <div class="row">
                <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
                    <div class="position-sticky pt-3 sidebar-sticky">
                        <?php $curPageName = substr($_SERVER["SCRIPT_NAME"],strrpos($_SERVER["SCRIPT_NAME"],"/")+1);?>
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link <?php if($curPageName=="index.php"){echo "active";} ?>" aria-current="page" href="index.php"> <span data-feather="home" class="align-text-bottom"></span>Dashboard</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php if($curPageName=="addrecord.php"){echo "active";} ?>" href=""><span data-feather="file" class="align-text-bottom"></span>Add Record</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php if($curPageName=="reports.php"){echo "active";} ?>" href="reports.php"><span data-feather="bar-chart-2" class="align-text-bottom"></span>Reports</a>
                            </li> 
                        </ul>  
                    </div>
                </nav>

                <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                        <h1 class="h2">Add New Record</h1>
                    </div>
                    <form action="addrecordaction.php" method="post">
                        <div class="mb-2">
                            <label for="patient_name" class="form-lebel">Name of Patient</label>
                            <input type="text" class="form-control" name="patient_name" id="" pattern="[A-Za-z ]+" placeholder="Patient Name" required>
                        </div>
                        

                        <div class="row g-3 align-items-center mb-2">
                            <div class="col-4">
                                <label for="age" class="form-label">Age</label>
                                <input type="number" class="form-control" name="age" id="" placeholder="Patient Age" required>
                            </div>
                            <div class="col-4">
                                <label for="" class="form-label">Cause</label>
                                <select class="form-select" aria-label="Default select example" name="cause">
                                    <option selected disabled>Select One</option>
                                    <option value="Infection">Infection</option>
                                    <option value="Hormonal imbalances">Hormonal imbalances</option>
                                    <option value="Uterine abnormalities">Uterine abnormalitiesee</option>
                                    <option value="Severe kidney disease">Severe kidney disease</option>
                                    <option value="Congenital heart disease">Congenital heart disease</option>
                                    <option value="Diabetes that isn't managed">Diabetes that isn't managed</option>
                                    <option value="Thyroid disease">Thyroid disease</option>
                                    <option value="Radiation">Radiation</option>
                                    <option value="Severe malnutrition">Severe malnutrition</option>
                                    <option value="Incompetent cervix">Incompetent cervix</option>
                                    <option value="Exposure to TORCH diseases">Exposure to TORCH diseases</option>
                                    <option value="Lifestyle factors">Lifestyle factors</option>
                                </select>
                            </div>
                            <div class="col-4">
                                <label for="district" class="col-form-label">Abortion Type</label>
                                <select class="form-select" aria-label="Default select example" name="type">
                                    <option selected disabled>Seclect One</option>
                                    <option value="Incomplete Abortion">Incomplete Abortion</option>
                                    <option value="Complete Abortion">Complete Abortion</option>
                                    <option value="Missed Abortion">Missed Abortion</option>
                                </select>
                            </div>

                        </div>

                        <div class="row g-3 align-items-center mb-2">
                            <div class="col-4">
                                <label for="" class="form-label">Relegion</label><br>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="relegion" id="inlineRadio1" value="Islam" checked>
                                    <label class="form-check-label" for="inlineRadio1">Islam</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="relegion" id="inlineRadio2" value="Hindu">
                                    <label class="form-check-label" for="inlineRadio2">Hindu</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="relegion" id="inlineRadio3" value="Other" >
                                    <label class="form-check-label" for="inlineRadio3">Other</label>
                                </div>
                            </div>
                            <div class="col-4">
                                <label for="" class="form-label">Marital Status</label>
                                <br>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="marital_status" id="inlineRadio1" value="Married" checked>
                                    <label class="form-check-label" for="inlineRadio1">Married</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="marital_status" id="inlineRadio2" value="Unmarried">
                                    <label class="form-check-label" for="inlineRadio2">Unmarried</label>
                                </div>
                                
                            </div>
                            <div class="col-4">
                                <label for="district" class="col-form-label">District</label>
                                <select class="form-select" name="district" aria-label="Default select example" name="district" required>
                                    <option selected disabled>Select District</option>
                                    <option value="Bagerhat">Bagerhat</option>
                                    <option value="Bandarban">Bandarban</option>
                                    <option value="Barguna">Barguna</option>
                                    <option value="Barisal">Barisal</option>
                                    <option value="Bhola">Bhola</option>
                                    <option value="Bogra">Bogra</option>
                                    <option value="Brahmanbaria">Brahmanbaria</option>
                                    <option value="Chandpur">Chandpur</option>
                                    <option value="Chittagong">Chittagong</option>
                                    <option value="Chuadanga">Chuadanga</option>
                                    <option value="Comilla">Comilla</option>
                                    <option value="Cox'sBazar">Cox'sBazar</option>
                                    <option value="Dhaka">Dhaka</option>
                                    <option value="Dinajpur">Dinajpur</option>
                                    <option value="Faridpur">Faridpur</option>
                                    <option value="Feni">Feni</option>
                                    <option value="Gaibandha">Gaibandha</option>
                                    <option value="Gazipur">Gazipur</option>
                                    <option value="Gopalganj">Gopalganj</option>
                                    <option value="Habiganj">Habiganj</option>
                                    <option value="Jaipurhat">Jaipurhat</option>
                                    <option value="Jamalpur">Jamalpur</option>
                                    <option value="Jessore">Jessore</option>
                                    <option value="Jhalokati">Jhalokati</option>
                                    <option value="Jhenaidah">Jhenaidah</option>
                                    <option value="Khagrachari">Khagrachari</option>
                                    <option value="Khulna">Khulna</option>
                                    <option value="Kishoreganj">Kishoreganj</option>
                                    <option value="Kurigram">Kurigram</option>
                                    <option value="Kushtia">Kushtia</option>
                                    <option value="Lakshmipur">Lakshmipur</option>
                                    <option value="Lalmonirhat">Lalmonirhat</option>
                                    <option value="Madaripur">Madaripur</option>
                                    <option value="Magura">Magura</option>
                                    <option value="Manikganj">Manikganj</option>
                                    <option value="Maulvibazar">Maulvibazar</option>
                                    <option value="Meherpur">Meherpur</option>
                                    <option value="Munshiganj">Munshiganj</option>
                                    <option value="Mymensingh">Mymensingh</option>
                                    <option value="Naogaon">Naogaon</option>
                                    <option value="Narail">Narail</option>
                                    <option value="Narayanganj">Narayanganj</option>
                                    <option value="Narsingdi">Narsingdi</option>
                                    <option value="Natore">Natore</option>
                                    <option value="Nawabganj">Nawabganj</option>
                                    <option value="Netrokona">Netrokona</option>
                                    <option value="Nilphamari">Nilphamari</option>
                                    <option value="Noakhali">Noakhali</option>
                                    <option value="Pabna">Pabna</option>
                                    <option value="Panchagarh">Panchagarh</option>
                                    <option value="Patuakhali">Patuakhali</option>
                                    <option value="Pirojpur">Pirojpur</option>
                                    <option value="Rajbari">Rajbari</option>
                                    <option value="Rajshahi">Rajshahi</option>
                                    <option value="Rangamati">Rangamati</option>
                                    <option value="Rangpur">Rangpur</option>
                                    <option value="Satkhira">Satkhira</option>
                                    <option value="Shariatpur">Shariatpur</option>
                                    <option value="Sherpur">Sherpur</option>
                                    <option value="Sirajganj">Sirajganj</option>
                                    <option value="Sunamganj">Sunamganj</option>
                                    <option value="Sylhet">Sylhet</option>
                                    <option value="Tangail">Tangail</option>
                                    <option value="Thakurgaon">Thakurgaon</option>
                                </select>
                            </div>
                            
                        </div>

                        <div class="row g-3 align-items-center mb-2">
                            
                            <div class="col-4">
                                <label for="" class="form-label">Mother Dead?</label>
                                <select class="form-select" aria-label="Default select example" name="mother_dead">
                                    <option selected value="No">No</option>
                                    <option value="Yes">Yes</option>
                                    
                                </select>
                            </div>
                            <div class="col-4">
                                <label for="district" class="col-form-label">Baby Dead</label>
                                <select class="form-select" aria-label="Default select example" name="baby_dead">
                                    <option selected value="Yes">Yes</option>
                                    <option value="No">No</option>
                                    
                                </select>
                            </div>
                            <div class="col-4">
                                <label for="date" class="form-label">Date</label>
                                <input type="date" class="form-control" name="date" id="" name="date">
                            </div>

                        </div>
                        <button type="submit" class="btn btn-primary" name="submit" value="submit">Submit</button>
                    </form>

                    
                </main>
            </div>
        </div>
        <?php
        include "footer.php";
    }
?>