<?php
    session_start();
    if($_SESSION['email']=="" || $_SESSION['Org_Code']==""){
        header("Location: ../");
        exit();
    }else{
        
        include "../dbcon/dbcon.php";
        $org_code=$_SESSION['Org_Code'];
        $orgdata=mysqli_query($conn, "SELECT * FROM `hospital_list` WHERE Org_Code='$org_code'");
        $orginform=mysqli_fetch_assoc($orgdata);
        $hospital_name=$orginform['Name'];

        include "header.php";
        ?>
        <div class="container-fluid">
            <div class="row"> 
                <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
                    <div class="position-sticky pt-3 sidebar-sticky">
                        <?php $curPageName = substr($_SERVER["SCRIPT_NAME"],strrpos($_SERVER["SCRIPT_NAME"],"/")+1);?>
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link <?php if($curPageName=="index.php"){echo "active";} ?>" aria-current="page" href=""> <span data-feather="home" class="align-text-bottom"></span>Dashboard</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php if($curPageName=="addrecord.php"){echo "active";} ?>" href="addrecord.php"><span data-feather="file" class="align-text-bottom"></span>Add Record</a>
                            </li>
                            
                            <li class="nav-item">
                                <a class="nav-link <?php if($curPageName=="reports.php"){echo "active";} ?>" href="reports.php"><span data-feather="bar-chart-2" class="align-text-bottom"></span>Reports</a>
                            </li>
                            
                        </ul>

                        
                    </div>
                </nav>

                <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                
                    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                        <h1 class="h2">Dashboard</h1>
                        
                    </div>

                    <div class="row row-cols-1 row-cols-md-3 g-4">
                        <div class="col">
                            <div class="card h-100">
                                <!-- <img src="..." class="card-img-top" alt="..."> -->
                                <div class="card-body">
                                    <h5 class="card-title text-center">Case of <?php echo date("Y"); ?></h5>
                                    <p class="card-text text-center fs-1 fw-bold">
                                        <?php
                                            $result_this_year = mysqli_query($conn, "SELECT COUNT(Name) FROM `abortion_data` WHERE Name_of_Hospital='$hospital_name' And Date>='".date('Y')."-01-01' AND Date<='".date('Y')."-12-31'");
                                            $this_year_case = mysqli_fetch_assoc($result_this_year);
                                            echo $this_year_case['COUNT(Name)'];
                                        ?>
                                    </p>
                                </div>
                                <!-- <div class="card-footer">
                                    <small class="text-muted">Last updated 3 mins ago</small>
                                </div> -->
                            </div>
                        </div>
                        <div class="col">
                            <div class="card h-100">
                                <!-- <img src="..." class="card-img-top" alt="..."> -->
                                <div class="card-body">
                                    <h5 class="card-title text-center">Case of Last year</h5>
                                    <p class="card-text text-center fs-1 fw-bold">
                                        <?php
                                            $y=1;
                                            $result_year_before = mysqli_query($conn, "SELECT COUNT(Name) FROM `abortion_data` WHERE Name_of_Hospital='$hospital_name' And Date>='".date('Y')-$y."-01-01' AND Date<='".date('Y')-$y."-12-31'");
                                            $last_year_case = mysqli_fetch_assoc($result_year_before);
                                            echo $last_year_case['COUNT(Name)'];
                                        ?>
                                    </p>
                                </div>
                                <!-- <div class="card-footer">
                                    <small class="text-muted">Last updated 3 mins ago</small>
                                </div> -->
                            </div>
                        </div>
                        <div class="col">
                            <div class="card h-100">
                                <!-- <img src="..." class="card-img-top" alt="..."> -->
                                <div class="card-body">
                                    <h5 class="card-title text-center">Total Case Number</h5>
                                    <p class="card-text text-center fs-1 fw-bold">
                                        <?php
                                            $result_total = mysqli_query($conn, "SELECT COUNT(Name) FROM `abortion_data` WHERE Name_of_Hospital='$hospital_name'");
                                            $total_case = mysqli_fetch_assoc($result_total);
                                            echo $total_case['COUNT(Name)'];
                                        ?>
                                    </p>
                                </div>
                                <!-- <div class="card-footer">
                                    <small class="text-muted">
                                        
                                    </small>
                                </div> -->
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </div>
        <?php
        include "footer.php";
    }
?>