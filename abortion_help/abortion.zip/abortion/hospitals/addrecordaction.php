<?php
    session_start();
    include "../dbcon/dbcon.php";
    $org_code=$_SESSION['Org_Code'];
    $orgdata=mysqli_query($conn, "SELECT * FROM `hospital_list` WHERE Org_Code='$org_code'");
    $orginform=mysqli_fetch_assoc($orgdata);
    //echo $orginform['Name'];
    $name_of_hospital=$orginform['Name'];
    //print_r($_POST);
    $name=filter_var ( $_POST['patient_name'], FILTER_SANITIZE_STRING);
    $age=filter_var ( $_POST['age'], FILTER_SANITIZE_NUMBER_INT);
    $age=filter_var ( $age, FILTER_VALIDATE_INT);
    $cause=filter_var ( $_POST['cause'], FILTER_SANITIZE_STRING);
    $type=filter_var ( $_POST['type'], FILTER_SANITIZE_STRING);
    $relegion=filter_var ( $_POST['relegion'], FILTER_SANITIZE_STRING);
    $marital_status=filter_var ( $_POST['marital_status'], FILTER_SANITIZE_STRING);
    $district=filter_var ( $_POST['district'], FILTER_SANITIZE_STRING);
    $mother_dead=filter_var ( $_POST['mother_dead'], FILTER_SANITIZE_STRING);
    $baby_dead=filter_var ( $_POST['baby_dead'], FILTER_SANITIZE_STRING);
    $date=$_POST['date'];
    $stmt = $conn->prepare("INSERT INTO `abortion_data`(`Date`, `Name`, `Age`, `District`, `Marital_Status`, `Cause`, `Religion`, `Name_of_Hospital`, `Type`, `Baby_Death`, `Mother_Death`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssissssssss", $date, $name, $age, $district, $marital_status, $cause, $relegion, $name_of_hospital, $type, $baby_dead, $mother_dead);
    if($stmt->execute()){
        echo "<script>alert('Data Inserted');window.location.replace('index.php');</script>";
        // header('Location: index.php');
    }
?>