<?php
    session_start();
    if($_SESSION['email']=="" || $_SESSION['Org_Code']==""){
        header("Location: ../");
        exit();
    }else{
        include "../dbcon/dbcon.php";
        $org_code=$_SESSION['Org_Code'];
        $orgdata=mysqli_query($conn, "SELECT * FROM `hospital_list` WHERE Org_Code='$org_code'");
        $orginform=mysqli_fetch_assoc($orgdata);

        include "header.php";
        ?>
        <div class="container-fluid">
            <div class="row">
                <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
                    <div class="position-sticky pt-3 sidebar-sticky">
                        <?php $curPageName = substr($_SERVER["SCRIPT_NAME"],strrpos($_SERVER["SCRIPT_NAME"],"/")+1);?>
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link <?php if($curPageName=="index.php"){echo "active";} ?>" aria-current="page" href="index.php"> <span data-feather="home" class="align-text-bottom"></span>Dashboard</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php if($curPageName=="addrecord.php"){echo "active";} ?>" href="addrecord.php"><span data-feather="file" class="align-text-bottom"></span>Add Record</a>
                            </li>
                            
                            <li class="nav-item">
                                <a class="nav-link <?php if($curPageName=="reports.php"){echo "active";} ?>" href=""><span data-feather="bar-chart-2" class="align-text-bottom"></span>Reports</a>
                            </li>
                            
                        </ul>

                        
                    </div>
                </nav>

                <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                    <?php //print_r($orginform); 
                        $hospital_name=$orginform['Name'];
                    ?>
                    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                        <h1 class="h2">Report</h1>
                        
                    </div>
                    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
                    <script type="text/javascript">
                        <?php 
                            $y=1;
                            $x=date('Y')-$y;
                        ?>
                        google.charts.load('current', {'packages':['corechart']});
                        google.charts.setOnLoadCallback(drawChart);
                        function drawChart() {
                            var data = google.visualization.arrayToDataTable([
                            ['Month', 'Number of Case'],
                            ['January', <?php
                                $sqljan="SELECT COUNT(Name) FROM `abortion_data` WHERE Name_of_Hospital='$hospital_name' AND Date>='$x-01-01' AND Date<='$x-01-31'";
                                $resultjan = $conn->query($sqljan);
                                $rowjan = $resultjan->fetch_assoc();
                                echo $rowjan['COUNT(Name)'];
                                        ?>],
                            ['February',  <?php
                                        $sqlfeb="SELECT COUNT(Name) FROM `abortion_data` WHERE Name_of_Hospital='$hospital_name' AND Date>='$x-02-01' AND Date<='$x-02-29'";
                                        $resultfeb = $conn->query($sqlfeb);
                                        $rowfeb = $resultfeb->fetch_assoc();
                                        echo $rowfeb['COUNT(Name)'];
                                        ?>],
                            ['March',  <?php
                                        $sqlmarch="SELECT COUNT(Name) FROM `abortion_data` WHERE Name_of_Hospital='$hospital_name' AND Date>='$x-03-01' AND Date<='$x-03-31'";
                                        $resultmarch = $conn->query($sqlmarch);
                                        $rowmarch = $resultmarch->fetch_assoc();
                                        echo $rowmarch['COUNT(Name)'];
                                        ?>],
                            ['April',  <?php
                                        $sqlapril="SELECT COUNT(Name) FROM `abortion_data` WHERE Name_of_Hospital='$hospital_name' AND Date>='$x-04-01' AND Date<='$x-04-30'";
                                        $resultapril = $conn->query($sqlapril);
                                        $rowapril = $resultapril->fetch_assoc();
                                        echo $rowapril['COUNT(Name)'];
                                        ?>],
                            ['May',  <?php
                                        $sqlmay="SELECT COUNT(Name) FROM `abortion_data` WHERE Name_of_Hospital='$hospital_name' AND Date>='$x-05-01' AND Date<='$x-05-31'";
                                        $resultmay = $conn->query($sqlmay);
                                        $rowmay = $resultmay->fetch_assoc();
                                        echo $rowmay['COUNT(Name)'];
                                        ?>],
                            ['June',  <?php
                                        $sqljune="SELECT COUNT(Name) FROM `abortion_data` WHERE Name_of_Hospital='$hospital_name' AND Date>='$x-06-01' AND Date<='$x-06-30'";
                                        $resultjune = $conn->query($sqljune);
                                        $rowjune = $resultjune->fetch_assoc();
                                        echo $rowjune['COUNT(Name)'];
                                        ?>],
                            ['July',  <?php
                                        $sqljuly="SELECT COUNT(Name) FROM `abortion_data` WHERE Name_of_Hospital='$hospital_name' AND Date>='$x-07-01' AND Date<='$x-07-31'";
                                        $resultjuly = $conn->query($sqljuly);
                                        $rowjuly = $resultjuly->fetch_assoc();
                                        echo $rowjuly['COUNT(Name)'];
                                        ?>],
                            ['Augest',  <?php
                                        $sqlaug="SELECT COUNT(Name) FROM `abortion_data` WHERE Name_of_Hospital='$hospital_name' AND Date>='$x-08-01' AND Date<='$x-08-31'";
                                        $resultaug = $conn->query($sqlaug);
                                        $rowaug = $resultaug->fetch_assoc();
                                        echo $rowaug['COUNT(Name)'];
                                        ?>],
                            ['September',  <?php
                                        $sqlsep="SELECT COUNT(Name) FROM `abortion_data` WHERE Name_of_Hospital='$hospital_name' AND Date>='$x-09-01' AND Date<='$x-09-30'";
                                        $resultsep = $conn->query($sqlsep);
                                        $rowsep = $resultsep->fetch_assoc();
                                        echo $rowsep['COUNT(Name)'];
                                        ?>],
                            ['October',  <?php
                                        $sqloct="SELECT COUNT(Name) FROM `abortion_data` WHERE Name_of_Hospital='$hospital_name' AND Date>='$x-10-01' AND Date<='$x-10-31'";
                                        $resultoct = $conn->query($sqloct);
                                        $rowoct = $resultoct->fetch_assoc();
                                        echo $rowoct['COUNT(Name)'];
                                        ?>],
                            ['November',  <?php
                                        $sqlnov="SELECT COUNT(Name) FROM `abortion_data` WHERE Name_of_Hospital='$hospital_name' AND Date>='$x-09-01' AND Date<='$x-09-30'";
                                        $resultnov = $conn->query($sqlnov);
                                        $rownov = $resultnov->fetch_assoc();
                                        echo $rownov['COUNT(Name)'];
                                        ?>],
                            ['December',  <?php
                                        $sqldec="SELECT COUNT(Name) FROM `abortion_data` WHERE Name_of_Hospital='$hospital_name' AND Date>='$x-09-01' AND Date<='$x-09-30'";
                                        $resultdec = $conn->query($sqldec);
                                        $rowdec = $resultdec->fetch_assoc();
                                        echo $rowdec['COUNT(Name)'];
                                        ?>]
                            ]);

                            var options = {
                            title: 'Anual Report of <?php echo $x;?>',
                            curveType: 'function',
                            
                            legend: { position: 'bottom' }
                            };

                            var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));

                            chart.draw(data, options);
                        }
                    </script>
                    <div class="my-4 w-100" id="curve_chart" width="900" height="380" style="width: 900px; height: 380px"></div>
                    

                    <h2>Cases</h2>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                <th scope="col">#</th>
                                <th scope="col">Year</th>
                                <th scope="col">Total</th>
                                <th scope="col">Incomplete</th>
                                <th scope="col">Missed</th>
                                <th scope="col">Complete</th>
                                <th scope="col">Mother Dead</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $i=0;
                                    while($i>-10){
                                        ?>
                                        <tr>
                                            <td><?php echo abs($i-1); ?></td>
                                            <td><?php echo date("Y")+$i; ?></td>
                                            <?php $rxy=date("Y")+$i;?>
                                            <td><?php
                                                $sql010="SELECT COUNT(Name) FROM `abortion_data` WHERE Name_of_Hospital='$hospital_name' AND Date>='$rxy-01-01' AND Date<='$rxy-12-31'";
                                                $result010 = $conn->query($sql010);
                                                $row010 = $result010->fetch_assoc();
                                                echo $row010['COUNT(Name)'];
                                            ?></td>
                                            <td><?php
                                                $sql020="SELECT COUNT(Name) FROM `abortion_data` WHERE Name_of_Hospital='$hospital_name' AND Type='Incomplete Abortion' AND Date>='$rxy-01-01' AND Date<='$rxy-12-31'";
                                                $result020 = $conn->query($sql020);
                                                $row020 = $result020->fetch_assoc();
                                                echo $row020['COUNT(Name)'];
                                            ?></td>
                                            <td><?php
                                                $sql020="SELECT COUNT(Name) FROM `abortion_data` WHERE Name_of_Hospital='$hospital_name' AND Type='Missed Abortion' AND Date>='$rxy-01-01' AND Date<='$rxy-12-31'";
                                                $result020 = $conn->query($sql020);
                                                $row020 = $result020->fetch_assoc();
                                                echo $row020['COUNT(Name)'];
                                            ?></td>
                                            <td><?php
                                                $sql020="SELECT COUNT(Name) FROM `abortion_data` WHERE Name_of_Hospital='$hospital_name' AND Type='Complete Abortion' AND Date>='$rxy-01-01' AND Date<='$rxy-12-31'";
                                                $result020 = $conn->query($sql020);
                                                $row020 = $result020->fetch_assoc();
                                                echo $row020['COUNT(Name)'];
                                            ?></td>
                                            <td><?php
                                                $sql020="SELECT COUNT(Name) FROM `abortion_data` WHERE Name_of_Hospital='$hospital_name' AND Mother_Death='Yes' AND Date>='$rxy-01-01' AND Date<='$rxy-12-31'";
                                                $result020 = $conn->query($sql020);
                                                $row020 = $result020->fetch_assoc();
                                                echo $row020['COUNT(Name)'];
                                            ?></td>
                                        </tr>
                                        <?php
                                        $i--;
                                    }
                                ?>
                                
                                
                            </tbody>
                        </table>
                    </div>
                </main>
            </div>
        </div>
        <?php
        include "footer.php";
    }
?>