<?php
  include "header.php";
  include "dbcon/dbcon.php";
?>

<section class=" gradient-custom-2" style="min-height:100vh">
  <div class="container py-5 h-100">
    <div class="row search_org">
        <div class="col-md-3"></div>
        <div class="col-md-6 bg-success bg-opacity-75 p-3 rounded">
          <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post" class="row g-3">
            <div class="col-md-4 col-12">
              <!-- <label for="staticEmail2" class="form-labe;">Organization Code</label> -->
              <!-- <input type="text" readonly class="form-control-plaintext" id="staticEmail2" value="email@example.com"> -->
              <p class="m-auto text-center text-light">Organization Code</p>
            </div>
            <div class="col-md-4 col-12">
              <label for="inputPassword2" class="visually-hidden">Organization Code</label>
              <input type="text" name="org_code" class="form-control" id="inputPassword2" placeholder="Ex:10019221"
                required>
            </div>
            <div class="col-md-4 col-12">
              <button type="submit" class="btn btn-primary" name="search_hospital"
                value="search_hospital_submit">Search</button>
            </div>
          </form>
        </div>
        <div class="col-md-3"></div>
    </div>
    <?php
      if ($_SERVER["REQUEST_METHOD"] == "POST"){
        if(isset($_POST['search_hospital'])){
          $org_code=filter_var ($_POST['org_code'] , FILTER_SANITIZE_STRING);
          $sql = "SELECT * FROM `user` WHERE `Org_Code`='$org_code'";
          
          $result = $conn->query($sql);
          
          if ($result->num_rows > 0) {
            // output data of each row
            echo "<script> alert('Already Has An Account');window.location.replace('login_form.html') </script>";
          } else {
            $sql=$result="";
            $sql = "SELECT * FROM `hospital_list` WHERE `Org_Code`='$org_code'";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
              // output data of each row
              while($row = $result->fetch_assoc()) {
                //print_r($row);
                ?>
                  <style>
                    .search_org{display:none !important}
                    /* .reg_form{display:block !important} */
                  </style>
                  <div class="row d-flex justify-content-center align-items-center h-100  reg_form">
                    <div class="col-12">
                      <form action="regestration_action.php" method="post">
                        <div class="card card-registration card-registration-2" style="border-radius: 15px;">
                          <div class="card-body p-0">
                            <div class="row g-0">
                              <div class="col-lg-6">
                                <div class="p-md-5 p-1">
                                  <h3 class="fw-normal mb-4" style="color: #4835d4;">General Infomation</h3>

                                  <div class="mb-3">
                                    <label for="Name" class="form-label">Organization Name</label>
                                    <input class="form-control" name="Name" type="text" value="<?php echo $row['Name'];?>" aria-label="readonly input example" readonly>
                                  </div>

                                  
                                  <div class="mb-3">
                                    <label for="Org_Type" class="form-label">Organization Type</label>
                                    <input class="form-control" name="Org_Type" type="text" value="<?php echo $row['Org_Type'];?>" aria-label="readonly input example" readonly>
                                  </div>
                                  <input type="hidden" name="Org_Code" value="<?php echo $row['Org_Code'] ?>">

                                  <div class="mb-3 pb-2">
                                    <label for="Established" class="form-label">Established</label>
                                    <?php $years = range(1800, strftime("%Y", time())); ?>
                                    <select class="form-select" name="Established" aria-label="Default select example" <?php if($row['Established']!=""){echo "";} ?>>
                                      <?php
                                        if($row['Established']!=""){
                                          ?><option value="<?php echo $row['Established'];?>"><?php echo $row['Established'];?></option><?php
                                        }else{
                                          ?>
                                          
                                          <?php if($row['Established']==""){foreach($years as $year) : ?>
                                            <option value="<?php echo $year; ?>"><?php echo $year; ?></option>
                                          <?php endforeach;} ?>
                                          <option selected>Select Year</option>
                                          <?php
                                        }
                                      ?>
                                      
                                    </select>
                                    
                                  </div>


                                  <div class="row g-2">
                                    <div class="col-md-6 mb-4 pb-2 mb-md-0 pb-md-0">
                                      <label for="Division" class="form-label">Division</label>
                                      <input class="form-control" name="Division" type="text" value="<?php echo $row['Division'];?>" aria-label="readonly input example" readonly>
                                    </div>
                                    <div class="col-md-6">
                                      <label for="District" class="form-label">District</label>
                                      <input class="form-control" name="District" type="text" value="<?php echo $row['District'];?>" aria-label="readonly input example" readonly>
                                    </div>
                                    <div class="col-md-6">
                                      <label for="Upazila" class="form-label">Upazila</label>
                                      <input class="form-control" name="Upazila" type="text" value="<?php echo $row['Upazila'];?>" aria-label="readonly input example" readonly>
                                    </div>
                                    <div class="col-md-6">
                                      <label for="Union_p" class="form-label">Union</label>
                                      <input type="text" name="Union_p" class="form-control" placeholder="Union" aria-label="Union" value="<?php echo $row['Union_p'] ?>" aria-describedby="basic-addon1">
                                    </div>
                                    <div class="col-md-6">
                                      <label for="Ward" class="form-label">Ward</label>
                                      <input type="text" name="Ward" class="form-control" placeholder="Ward" aria-label="Ward" value="<?php echo $row['Ward'] ?>" aria-describedby="basic-addon1">
                                    </div>
                                    <div class="col-md-6">
                                      <label for="House_No" class="form-label">House No</label>
                                      <input type="text" name="House_No" class="form-control" placeholder="House No" aria-label="House No" value="<?php echo $row['House_No'] ?>" aria-describedby="basic-addon1">
                                    </div>
                                    <div class="col-md-12">
                                      <label for="" class="form-label">Village/Street</label>
                                      <input type="text" name="Village_Street" class="form-control" placeholder="Village/Street" aria-label="Village/Street" value="<?php echo $row['Village_Street'] ?>" aria-describedby="basic-addon1">
                                    </div>
                                  </div>

                                </div>
                              </div>
                              <div class="col-lg-6 bg-indigo text-white">
                                <div class="p-md-5 p-1">
                                  <h3 class="fw-normal mb-4">Contact Details</h3>

                                  <div class="mb-4 pb-2">
                                    <div class="form-outline form-white">
                                      <label class="form-label" for="Mailing_Address">Mailing Address</label>
                                      <textarea class="form-control" name="Mailing_Address" placeholder="Mailing Address" id="" value="" spellcheck="false"><?php echo $row['Mailing_Address'] ?></textarea>
                                      
                                    </div>
                                  </div>

                                  <div class="row">
                                    <div class="col-md-6 mb-4 pb-2">

                                      <div class="form-outline form-white">
                                        
                                        <label class="form-label" for="Mobile_Phones">Mobile No.</label>
                                        <input type="tel" name="Mobile_Phones" id="" class="form-control form-control-lg" value="<?php echo stripslashes(trim($row['Mobile_Phones'])) ?>" minlength="11" pattern="^(?:\+88|01)?\d{11}\r?$" required>
                                      </div>

                                    </div>
                                    <div class="col-md-6 mb-4 pb-2">

                                      <div class="form-outline form-white">
                                        <label class="form-label" for="Land_Phones">Land Phone No.</label>
                                        <input type="tel" name="Land_Phones" id="" class="form-control form-control-lg" value="<?php echo stripslashes(trim($row['Land_Phones'])) ?>">
                                        
                                      </div>

                                    </div>
                                    <div class="col-md-4 mb-4">
                                      <div class="form-outline form-white">
                                        <label class="form-label" for="Faxs">Fax</label>
                                        <input type="tel" name="Faxs" id="" class="form-control form-control-lg" value="<?php echo $row['Faxs'] ?>">
                                      </div>
                                    </div>
                                    <div class="col-md-8 mb-4">
                                      <div class="form-outline form-white">
                                        <label class="form-label" for="Website">Website</label>
                                        <input type="text" name="Website" id="" class="form-control form-control-lg" value="<?php echo $row['Website'] ?>">
                                      </div>
                                    </div>
                                  </div>

                                  <div class="mb-4">
                                    <div class="form-outline form-white">
                                      <label class="form-label" for="Email">Organization Email</label>
                                      
                                      <input type="email" name="Email" id="" class="form-control form-control-lg" value="<?php echo $row['Email'] ?>" required>
                                      
                                    </div>
                                  </div>

                                  <div class="form-check d-flex justify-content-start mb-4 pb-3">
                                    <input class="form-check-input me-3" name="agreement" type="checkbox" value="agree" id="form2Example3c" required>
                                    <label class="form-check-label text-white" for="form2Example3">
                                      I do accept the <a href="" class="text-light" data-bs-toggle="modal" data-bs-target="#exampleModal"><u>Terms and Conditions</u></a> of
                                      your
                                      site.
                                    </label>
                                    <!-- Modal -->
                                    <div class="modal fade text-dark" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                      <div class="modal-dialog">
                                        <div class="modal-content">
                                          <div class="modal-header">
                                            <h5 class="modal-title">Terms and Conditions</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                              aria-label="Close"></button>
                                          </div>
                                          <div class="modal-body">
                                            <ol class="list-group list-group-numbered">
                                              <li
                                                class="list-group-item d-flex justify-content-between align-items-start">
                                                <div class="ms-2 me-auto">
                                                  <div class="fw-bold">Subheading</div>
                                                  Content for list item
                                                </div>
                                                <!-- <span class="badge bg-primary rounded-pill">14</span> -->
                                              </li>
                                              <li
                                                class="list-group-item d-flex justify-content-between align-items-start">
                                                <div class="ms-2 me-auto">
                                                  <div class="fw-bold">Subheading</div>
                                                  Content for list item
                                                </div>
                                                <!-- <span class="badge bg-primary rounded-pill">14</span> -->
                                              </li>
                                              <li
                                                class="list-group-item d-flex justify-content-between align-items-start">
                                                <div class="ms-2 me-auto">
                                                  <div class="fw-bold">Subheading</div>
                                                  Content for list item
                                                </div>
                                                <!-- <span class="badge bg-primary rounded-pill">14</span> -->
                                              </li>
                                            </ol>
                                          </div>
                                          <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary"
                                              data-bs-dismiss="modal">Close</button>
                                            
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  

                                  <button type="submit" class="btn btn-light btn-lg" data-mdb-ripple-color="dark" name="reg_submit" value="reg">Register</button>

                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </form>

                    </div>
                  </div>
                <?php
              }
            } else {
              echo "<script> alert('No Such Hospital Listed') </script>";
            }
          }
        }
      }
    ?>
    
    
  </div>
</section>

<?php
  include "footer.php";
?>