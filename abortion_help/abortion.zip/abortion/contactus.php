<?php include "header.php"; ?>
<section class="conus_main bg-success py-4" style="--bs-bg-opacity: .25;">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h3 class="pb-3">Any Question? Just Ask...</h3>
                <form action="contactus_action.php" method="post">
                    <div class="form-floating mb-3">
                        <input type="text" name="name" class="form-control" id="floatingInput" placeholder="Your Name">
                        <label for="floatingInput">Your Name</label>
                    </div>
                    <div class="form-floating mb-3">
                        <input type="email" name="email" class="form-control" id="floatingInput" placeholder="name@example.com" required>
                        <label for="floatingInput">Email address</label>
                    </div>
                    <div class="form-floating mb-3">
                        <input type="text" name="Subject" class="form-control" id="floatingInput" placeholder="Subject">
                        <label for="floatingInput">Subject</label>
                    </div>
                    <div class="form-floating mb-3">
                        <textarea name="message" class="form-control" placeholder="Write the Question Here" id="floatingTextarea2" style="height: 100px" required></textarea>
                        <label for="floatingTextarea2">Message</label>
                    </div>
                    <button type="submit" class="btn btn-primary float-end">Submit</button>
                </form>
            </div>
            <div class="col-md-6">
            
                <img src="img/Doctors.jpg" class="img-fluid rounded opacity-75" alt="" srcset="">
            </div>
        </div>
    </div>
</section>
<?php include "footer.php"; ?>