<?php 
    include "dbcon/dbcon.php";
    // print_r($_POST);
    // $name=$subject="";
    $name= filter_var($_POST['name'], FILTER_SANITIZE_STRING);
    
    $email= filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
        $email=$email;
    }else{$email="";}
    $subject= filter_var($_POST['Subject'], FILTER_SANITIZE_STRING);
    $message= filter_var($_POST['message'], FILTER_SANITIZE_STRING);
    if($email!="" && $message!=""){
        //echo $email;
        $sql="";
        $sql="INSERT INTO `questions`(`name`, `email`, `subject`, `message`, `ask_time`, `answer`) VALUES ('$name','$email','$subject','$message',NOW(),'')";
        if ($conn->query($sql) === TRUE) {
            require 'phpmailer/PHPMailerAutoload.php';
            $mail = new PHPMailer;
            $sender_email = 'rahatparvej2@gmail.com';
            $sender_pass = '11221234121';
    
            $receiver = $email;
            // $mail->isSMTP(); // for localhost use enable this line otherwise don't use it
            $mail->Host = 'smtp.gmail.com';
            $mail->Port = 465;
            $mail->SMTPAuth = true;
            $mail->SMTPSecure = 'tls';
    
            $mail->Username = $sender_email; // Sender Email Id
            $mail->Password = $sender_pass; // password of gmail
    
            $mail->setFrom($sender_email,'Abortion Help');
    
            $mail->addAddress($receiver); // Receiver Email Address
            $mail->addReplyTo($sender_email);
    
            $mail->isHTML(true);
            $mail->Subject = "Thank You for Sending Message on Abortion Help";
            $mail->Body = '<h5>Dear Sir, <br>Thank you for you message. We will try to respond to your message as soon as possible.<br>Best regards,<br><b>Abortion Help</b></h5>';
            if($mail->send())
            {
                $mail->ClearAddresses();
                $mail->clearReplyTos();
                // mail_sent = 1 kore dilam er mane mail sent hoyse.
                $mail_sent = 1;
            }
            if($mail_sent==1){
                echo "<script>alert('Thank You For your Query. You will get response Soon');window.location.replace('index.php');</script>";
            }
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }else{
        echo "<script>alert('Please Fill The Form Properly');location.replace('contactus.php')</script>";
    }
    
?>