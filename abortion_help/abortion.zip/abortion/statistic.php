<?php
  include "header.php";
  Include "dbcon/dbcon.php";
?>
  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
  <section style="background:rgb(235, 240, 255)">
    <div class="container">
      <div class="row">
        <div class="col-md-12 py-5 text-center">
          <h3 class="text-center mb-3">Last 1 year senario</h3>
          <div class="row row-cols-1 row-cols-md-4 g-4">
            <div class="col">
              <div class="card mx-auto bg-primary text-white text-center bg-gradient" style="width: auto;    height: 160px;cursor: -webkit-grabbing; cursor: grabbing;">
                <div class="card-body">
                  <h5 class="card-title mb-3 text-bolter">Total number of Case</h5>
                  
                  <p class="card-text fs-1">
                  <?php
                    
                    $d=mktime( 0,0 ,0 ,date('m'), date('d'), date('y')-1);
                    $date= date("Y-m-d", $d);
                    $cont=0;
                    $sql = 'SELECT * FROM `abortion_data` WHERE 1';
                    $result = $conn->query($sql);
                    if ($result->num_rows > 0) {
                    // output data of each row
                    while($row = $result->fetch_assoc()) {
                        $datedata= strtotime($row['Date']);
                        $ddata=date('Y-m-d', $datedata);
                        //echo $ddata."<br>";
                        if($ddata>$date)
                        $cont++;
                        
                    } echo $cont;
                    } else {
                        
                    }
                  ?>
                  </p>
                  
                </div>
              </div>
            </div>
            <div class="col">
              <div class="card mx-auto bg-success text-white text-center bg-gradient" style="width: auto;    height: 160px;cursor: -webkit-grabbing; cursor: grabbing;">
                <div class="card-body">
                  <h5 class="card-title mb-3 text-bolder">Incomplete Abortion</h5>
                  
                  <p class="card-text fs-1">
                  <?php
                    $cont=0;
                    $sql = 'SELECT * FROM `abortion_data` WHERE Type="Incomplete Abortion"';
                    $result = $conn->query($sql);
                    if ($result->num_rows > 0) {
                    // output data of each row
                    while($row = $result->fetch_assoc()) {
                        $datedata= strtotime($row['Date']);
                        $ddata=date('Y-m-d', $datedata);
                        //echo $ddata."<br>";
                        if($ddata>$date)
                        $cont++;
                        
                    } echo $cont;
                    } else {
                        
                    }
                  ?>
                  </p>
                  
                </div>
              </div>
            </div>
            <div class="col">
              <div class="card mx-auto bg-danger text-white text-center bg-gradient" style="width: auto;    height: 160px;cursor: -webkit-grabbing; cursor: grabbing;">
                <div class="card-body">
                  <h5 class="card-title mb-3 text-bolter">Missed Abortion</h5>
                  
                  <p class="card-text fs-1">
                  <?php
                    $cont=0;
                    $sql = 'SELECT * FROM `abortion_data` WHERE Type="Missed Abortion"';
                    $result = $conn->query($sql);
                    if ($result->num_rows > 0) {
                    // output data of each row
                    while($row = $result->fetch_assoc()) {
                        $datedata= strtotime($row['Date']);
                        $ddata=date('Y-m-d', $datedata);
                        //echo $ddata."<br>";
                        if($ddata>$date)
                        $cont++;
                        
                    } echo $cont;
                    } else {
                        
                    }
                  ?>
                  </p>
                  
                </div>
              </div>
            </div>
            <div class="col">
            <div class="card mx-auto bg-dark text-white text-center bg-gradient" style="width: auto;    height: 160px;cursor: -webkit-grabbing; cursor: grabbing;">
                <div class="card-body">
                  <h5 class="card-title mb-3 text-bolder">Mother Dead</h5>
                  
                  <p class="card-text fs-1">
                  <?php
                    $cont=0;
                    $sql = 'SELECT * FROM `abortion_data` WHERE Type="Mother Dead"';
                    $result = $conn->query($sql);
                    if ($result->num_rows > 0) {
                    // output data of each row
                    while($row = $result->fetch_assoc()) {
                        $datedata= strtotime($row['Date']);
                        $ddata=date('Y-m-d', $datedata);
                        //echo $ddata."<br>";
                        if($ddata>$date)
                        $cont++;
                        
                    } echo $cont;
                    } else {
                        echo 0;
                    }
                  ?>
                  </p>
                  
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  </section>
  
  <script type="text/javascript">
        function update() {
          if(document.getElementById('selectfilter').value=='division'){
            document.getElementById('district').style.display = 'block';
          }else{
            document.getElementById('district').style.display = 'none';
          }
        }
        update();   
  </script>
      <div class="container">
        <div class="row pt-5">
          <div class="col-md-12">
            <h1 class="text-center">Total Senario</h1>
            <form class="pb-5" method="get" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>">
              <div class="row g-3 align-items-center">
                <legend>Filter:</legend>
                <div class="col-auto">
                  <select id="selectfilter" onChange="update()" class="form-select" aria-label="Default select example" name="filter">
                    <option value="Age" <?php if($_GET['filter']=='Age'){echo "selected";} ?>>Age</option>
                    <option value="division" <?php if($_GET['filter']=='division'){echo "selected";} ?>>District</option>
                    <option value="Religion" <?php if($_GET['filter']=='Religion'){echo "selected";} ?>>Religion</option>
                    <option value="Baby_Death" <?php if($_GET['filter']=='Baby_Death'){echo "selected";} ?>>Baby Death</option>
                    <option value="Mother_Death" <?php if($_GET['filter']=='Mother_Death'){echo "selected";} ?>>Mother Death</option>
                  </select>
                </div>
                <div class="col-auto" id="district" style="<?php if($_GET['filter']=='division'){echo "display:block;";}else{echo "display:none;";} ?>" onChange="">
                  <select name="district" id="district_name" class="form-select" required>
                    <option value="select">Select District</option>
                    <option value="Bagerhat" <?php if($_GET['district']=='Bagerhat'){echo "selected";}?>>Bagerhat</option>
                    <option value="Bandarban" <?php if($_GET['district']=='Bandarban'){echo "selected";}?>>Bandarban</option>
                    <option value="Barguna" <?php if($_GET['district']=='Barguna'){echo "selected";}?>>Barguna</option>
                    <option value="Barisal" <?php if($_GET['district']=='Barisal'){echo "selected";}?>>Barisal</option>
                    <option value="Bhola" <?php if($_GET['district']=='Bhola'){echo "selected";}?>>Bhola</option>
                    <option value="Bogra" <?php if($_GET['district']=='Bogra'){echo "selected";}?>>Bogra</option>
                    <option value="Brahmanbaria" <?php if($_GET['district']=='Brahmanbaria'){echo "selected";}?>>Brahmanbaria</option>
                    <option value="Chandpur" <?php if($_GET['district']=='Chandpur'){echo "selected";}?>>Chandpur</option>
                    <option value="Chittagong" <?php if($_GET['district']=='Chittagong'){echo "selected";}?>>Chittagong</option>
                    <option value="Chuadanga" <?php if($_GET['district']=='Chuadanga'){echo "selected";}?>>Chuadanga</option>
                    <option value="Comilla" <?php if($_GET['district']=='Comilla'){echo "selected";}?>>Comilla</option>
                    <option value="CoxsBazar" <?php if($_GET['district']=='CoxsBazar'){echo "selected";}?>>Cox'sBazar</option>
                    <option value="Dhaka" <?php if($_GET['district']=='Dhaka'){echo "selected";}?>>Dhaka</option>
                    <option value="Dinajpur" <?php if($_GET['district']=='Dinajpur'){echo "selected";}?>>Dinajpur</option>
                    <option value="Faridpur" <?php if($_GET['district']=='Faridpur'){echo "selected";}?>>Faridpur</option>
                    <option value="Feni" <?php if($_GET['district']=='Feni'){echo "selected";}?>>Feni</option>
                    <option value="Gaibandha" <?php if($_GET['district']=='Gaibandha'){echo "selected";}?>>Gaibandha</option>
                    <option value="Gazipur" <?php if($_GET['district']=='Gazipur'){echo "selected";}?>>Gazipur</option>
                    <option value="Gopalganj" <?php if($_GET['district']=='Gopalganj'){echo "selected";}?>>Gopalganj</option>
                    <option value="Habiganj" <?php if($_GET['district']=='Habiganj'){echo "selected";}?>>Habiganj</option>
                    <option value="Joypurhat" <?php if($_GET['district']=='Joypurhat'){echo "selected";}?>>Joypurhat</option>
                    <option value="Jamalpur" <?php if($_GET['district']=='Jamalpur'){echo "selected";}?>>Jamalpur</option>
                    <option value="Jessore" <?php if($_GET['district']=='Jessore'){echo "selected";}?>>Jessore</option>
                    <option value="Jhalokati" <?php if($_GET['district']=='Jhalokati'){echo "selected";}?>>Jhalokati</option>
                    <option value="Jhenaidah" <?php if($_GET['district']=='Jhenaidah'){echo "selected";}?>>Jhenaidah</option>
                    <option value="Khagrachari" <?php if($_GET['district']=='Khagrachari'){echo "selected";}?>>Khagrachari</option>
                    <option value="Khulna" <?php if($_GET['district']=='Khulna'){echo "selected";}?>>Khulna</option>
                    <option value="Kishoreganj" <?php if($_GET['district']=='Kishoreganj'){echo "selected";}?>>Kishoreganj</option>
                    <option value="Kurigram" <?php if($_GET['district']=='Kurigram'){echo "selected";}?>>Kurigram</option>
                    <option value="Kushtia" <?php if($_GET['district']=='Kushtia'){echo "selected";}?>>Kushtia</option>
                    <option value="Lakshmipur" <?php if($_GET['district']=='Lakshmipur'){echo "selected";}?>>Lakshmipur</option>
                    <option value="Lalmonirhat" <?php if($_GET['district']=='Lalmonirhat'){echo "selected";}?>>Lalmonirhat</option>
                    <option value="Madaripur" <?php if($_GET['district']=='Madaripur'){echo "selected";}?>>Madaripur</option>
                    <option value="Magura" <?php if($_GET['district']=='Magura'){echo "selected";}?>>Magura</option>
                    <option value="Manikganj" <?php if($_GET['district']=='Manikganj'){echo "selected";}?>>Manikganj</option>
                    <option value="Maulvibazar" <?php if($_GET['district']=='Maulvibazar'){echo "selected";}?>>Maulvibazar</option>
                    <option value="Meherpur" <?php if($_GET['district']=='Meherpur'){echo "selected";}?>>Meherpur</option>
                    <option value="Munshiganj" <?php if($_GET['district']=='Munshiganj'){echo "selected";}?>>Munshiganj</option>
                    <option value="Mymensingh" <?php if($_GET['district']=='Mymensingh'){echo "selected";}?>>Mymensingh</option>
                    <option value="Naogaon" <?php if($_GET['district']=='Naogaon'){echo "selected";}?>>Naogaon</option>
                    <option value="Narail" <?php if($_GET['district']=='Narail'){echo "selected";}?>>Narail</option>
                    <option value="Narayanganj" <?php if($_GET['district']=='Narayanganj'){echo "selected";}?>>Narayanganj</option>
                    <option value="Narsingdi" <?php if($_GET['district']=='Narsingdi'){echo "selected";}?>>Narsingdi</option>
                    <option value="Natore" <?php if($_GET['district']=='Natore'){echo "selected";}?>>Natore</option>
                    <option value="Nawabganj" <?php if($_GET['district']=='Nawabganj'){echo "selected";}?>>Nawabganj</option>
                    <option value="Netrokona" <?php if($_GET['district']=='Netrokona'){echo "selected";}?>>Netrokona</option>
                    <option value="Nilphamari" <?php if($_GET['district']=='Nilphamari'){echo "selected";}?>>Nilphamari</option>
                    <option value="Noakhali" <?php if($_GET['district']=='Noakhali'){echo "selected";}?>>Noakhali</option>
                    <option value="Pabna" <?php if($_GET['district']=='Pabna'){echo "selected";}?>>Pabna</option>
                    <option value="Panchagarh" <?php if($_GET['district']=='Panchagarh'){echo "selected";}?>>Panchagarh</option>
                    <option value="Patuakhali" <?php if($_GET['district']=='Patuakhali'){echo "selected";}?>>Patuakhali</option>
                    <option value="Pirojpur" <?php if($_GET['district']=='Pirojpur'){echo "selected";}?>>Pirojpur</option>
                    <option value="Rajbari" <?php if($_GET['district']=='Rajbari'){echo "selected";}?>>Rajbari</option>
                    <option value="Rajshahi" <?php if($_GET['district']=='Rajshahi'){echo "selected";}?>>Rajshahi</option>
                    <option value="Rangamati" <?php if($_GET['district']=='Rangamati'){echo "selected";}?>>Rangamati</option>
                    <option value="Rangpur" <?php if($_GET['district']=='Rangpur'){echo "selected";}?>>Rangpur</option>
                    <option value="Satkhira" <?php if($_GET['district']=='Satkhira'){echo "selected";}?>>Satkhira</option>
                    <option value="Shariatpur" <?php if($_GET['district']=='Shariatpur'){echo "selected";}?>>Shariatpur</option>
                    <option value="Sherpur" <?php if($_GET['district']=='Sherpur'){echo "selected";}?>>Sherpur</option>
                    <option value="Sirajganj" <?php if($_GET['district']=='Sirajganj'){echo "selected";}?>>Sirajganj</option>
                    <option value="Sunamganj" <?php if($_GET['district']=='Sunamganj'){echo "selected";}?>>Sunamganj</option>
                    <option value="Sylhet" <?php if($_GET['district']=='Sylhet'){echo "selected";}?>>Sylhet</option>
                    <option value="Tangail" <?php if($_GET['district']=='Tangail'){echo "selected";}?>>Tangail</option>
                    <option value="Thakurgaon" <?php if($_GET['district']=='Thakurgaon'){echo "selected";}?>>Thakurgaon</option>
                  </select>
                </div>
                <div class="col-auto">
                  <button type="submit" class="btn btn-primary">Apply</button>
                </div>
              </div>
            </form>

            <?php 
              if($_GET['filter']=='Age'){
                ?>
                  <marquee>Total Number of Sample Is: <big><?php
                    $sql=$row=$result='';
                    $sql='SELECT COUNT(Age) FROM `abortion_data` WHERE 1';
                    $result = $conn->query($sql);
                    $row = $result->fetch_assoc();
                    echo $row['COUNT(Age)'];
                  ?></big> </marquee>
                
                <script type="text/javascript">
                    google.charts.load('current', {'packages':['bar']});
                    google.charts.setOnLoadCallback(drawChart);

                    

                    function drawChart() {
                      var data = google.visualization.arrayToDataTable([
                        ['Age', 'Case Number'],
                        ['15-20', <?php
                                    $sql=$row=$result='';
                                    $sql='SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=15 and Age<=20';
                                    $result = $conn->query($sql);
                                    $row = $result->fetch_assoc();
                                    echo $row['COUNT(Age)'];
                                  ?>
                        ],
                        ['21-25', <?php
                                    $sql=$row=$result='';
                                    $sql='SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=21 and Age<=25';
                                    $result = $conn->query($sql);
                                    $row = $result->fetch_assoc();
                                    echo $row['COUNT(Age)'];
                                  ?>
                        ],
                        ['26-30', <?php
                                    $sql=$row=$result='';
                                    $sql='SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=26 and Age<=30';
                                    $result = $conn->query($sql);
                                    $row = $result->fetch_assoc();
                                    echo $row['COUNT(Age)'];
                                  ?>
                        ],
                        ['31-35', <?php
                                    $sql=$row=$result='';
                                    $sql='SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=31 and Age<=35';
                                    $result = $conn->query($sql);
                                    $row = $result->fetch_assoc();
                                    echo $row['COUNT(Age)'];
                                  ?>
                        ],
                        ['36-40', <?php
                                    $sql=$row=$result='';
                                    $sql='SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=36 and Age<=40';
                                    $result = $conn->query($sql);
                                    $row = $result->fetch_assoc();
                                    echo $row['COUNT(Age)'];
                                  ?>
                        ],
                        ['41-45', <?php
                                    $sql=$row=$result='';
                                    $sql='SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=41 and Age<=45';
                                    $result = $conn->query($sql);
                                    $row = $result->fetch_assoc();
                                    echo $row['COUNT(Age)'];
                                  ?>
                        ],
                        ['46+', <?php
                                    $sql=$row=$result='';
                                    $sql='SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=46';
                                    $result = $conn->query($sql);
                                    $row = $result->fetch_assoc();
                                    echo $row['COUNT(Age)'];
                                  ?>
                        ]
                      ]);

                      var options = {
                        chart: {
                          title: 'Abortion Statistic',
                          subtitle: 'Age Wise',
                        },
                        bars: 'vertical',
                        vAxis: {format: 'decimal',title:'Number Of case'},
                        hAxis:{title:'Age'},
                        height: 400,
                        width: 800,
                        colors: ['#1b9e77']
                      };

                      var chart = new google.charts.Bar(document.getElementById('chart_div'));

                      chart.draw(data, google.charts.Bar.convertOptions(options));

                      var btns = document.getElementById('btn-group');

                      btns.onclick = function (e) {

                        if (e.target.tagName === 'BUTTON') {
                          options.vAxis.format = e.target.id === 'none' ? '' : e.target.id;
                          chart.draw(data, google.charts.Bar.convertOptions(options));
                        }
                      }
                    }
                </script>
                  
                <script type="text/javascript">
                  google.charts.load('current', {'packages':['corechart']});
                  google.charts.setOnLoadCallback(drawChart);

                  function drawChart() {

                    var data = google.visualization.arrayToDataTable([
                      ['Age', 'Case Number'],
                      ['15-20', <?php
                                  $sql=$row=$result='';
                                  $sql='SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=15 and Age<=20';
                                  $result = $conn->query($sql);
                                  $row = $result->fetch_assoc();
                                  echo $row['COUNT(Age)'];
                                ?>
                      ],
                      ['21-25', <?php
                                  $sql=$row=$result='';
                                  $sql='SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=21 and Age<=25';
                                  $result = $conn->query($sql);
                                  $row = $result->fetch_assoc();
                                  echo $row['COUNT(Age)'];
                                ?>
                      ],
                      ['26-30', <?php
                                  $sql=$row=$result='';
                                  $sql='SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=26 and Age<=30';
                                  $result = $conn->query($sql);
                                  $row = $result->fetch_assoc();
                                  echo $row['COUNT(Age)'];
                                ?>
                      ],
                      ['31-35', <?php
                                  $sql=$row=$result='';
                                  $sql='SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=31 and Age<=35';
                                  $result = $conn->query($sql);
                                  $row = $result->fetch_assoc();
                                  echo $row['COUNT(Age)'];
                                ?>
                      ],
                      ['36-40', <?php
                                  $sql=$row=$result='';
                                  $sql='SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=36 and Age<=40';
                                  $result = $conn->query($sql);
                                  $row = $result->fetch_assoc();
                                  echo $row['COUNT(Age)'];
                                ?>
                      ],
                      ['41-45', <?php
                                  $sql=$row=$result='';
                                  $sql='SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=41 and Age<=45';
                                  $result = $conn->query($sql);
                                  $row = $result->fetch_assoc();
                                  echo $row['COUNT(Age)'];
                                ?>
                      ],
                      ['46+', <?php
                                  $sql=$row=$result='';
                                  $sql='SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=46';
                                  $result = $conn->query($sql);
                                  $row = $result->fetch_assoc();
                                  echo $row['COUNT(Age)'];
                                ?>
                      ]
                    ]);

                    var options = {
                      title: 'Abortion Statistic',
                      
                    };

                    var chart = new google.visualization.PieChart(document.getElementById('piechart'));

                    chart.draw(data, options);
                  }
                </script>
                <?php
              }else if($_GET['filter']=='division' && $_GET['district']!='select'){
                ?>
                
                  <marquee>Total Number of Sample Is: <big><?php
                    $sql=$row=$result='';
                    $sql="SELECT COUNT(name) FROM `abortion_data` WHERE District='".$_GET['district']."'";
                    $result = $conn->query($sql);
                    $row = $result->fetch_assoc();
                    echo $row['COUNT(name)'];
                  ?></big> </marquee>
                <script type="text/javascript">
                    google.charts.load('current', {'packages':['bar']});
                    google.charts.setOnLoadCallback(drawChart);
                    function drawChart() {
                      var data = google.visualization.arrayToDataTable([
                        ['Age', 'Case Number'],
                        ['15-20', <?php
                                    $sql=$row=$result='';
                                    $sql="SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=15 and Age<=20 and District='".$_GET['district']."'";
                                    $result = $conn->query($sql);
                                    $row = $result->fetch_assoc();
                                    echo $row['COUNT(Age)'];
                                  ?>],
                        ['21-25', <?php
                                    $sql=$row=$result='';
                                    $sql="SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=21 and Age<=25 and District='".$_GET['district']."'";
                                    $result = $conn->query($sql);
                                    $row = $result->fetch_assoc();
                                    echo $row['COUNT(Age)'];
                                  ?>],
                        ['26-30', <?php
                                    $sql=$row=$result='';
                                    $sql="SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=26 and Age<=30 and District='".$_GET['district']."'";
                                    $result = $conn->query($sql);
                                    $row = $result->fetch_assoc();
                                    echo $row['COUNT(Age)'];
                                  ?>],
                        ['31-35', <?php
                                    $sql=$row=$result='';
                                    $sql="SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=31 and Age<=35 and District='".$_GET['district']."'";
                                    $result = $conn->query($sql);
                                    $row = $result->fetch_assoc();
                                    echo $row['COUNT(Age)'];
                                  ?>],
                        ['36-40', <?php
                                    $sql=$row=$result='';
                                    $sql="SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=36 and Age<=40 and District='".$_GET['district']."'";
                                    $result = $conn->query($sql);
                                    $row = $result->fetch_assoc();
                                    echo $row['COUNT(Age)'];
                                  ?>],
                        ['41-45', <?php
                                    $sql=$row=$result='';
                                    $sql="SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=41 and Age<=45 and District='".$_GET['district']."'";
                                    $result = $conn->query($sql);
                                    $row = $result->fetch_assoc();
                                    echo $row['COUNT(Age)'];
                                  ?>],
                        ['46+', <?php
                                    $sql=$row=$result='';
                                    $sql="SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=46 and District='".$_GET['district']."'";
                                    $result = $conn->query($sql);
                                    $row = $result->fetch_assoc();
                                    echo $row['COUNT(Age)'];
                                  ?>]
                        
                      ]);

                      var options = {
                        chart: {
                          title: 'Abortion Statistic of <?php echo $_GET['district'] ?> District',
                          subtitle: 'Age Wise',
                        },
                        bars: 'vertical',
                        vAxis: {format: 'decimal',title:'Number Of case'},
                        hAxis:{title:'Age'},
                        height: 400,
                        width: 800,
                        colors: ['#1b9e77']
                      };

                      var chart = new google.charts.Bar(document.getElementById('chart_div'));

                      chart.draw(data, google.charts.Bar.convertOptions(options));

                      var btns = document.getElementById('btn-group');

                      btns.onclick = function (e) {

                        if (e.target.tagName === 'BUTTON') {
                          options.vAxis.format = e.target.id === 'none' ? '' : e.target.id;
                          chart.draw(data, google.charts.Bar.convertOptions(options));
                        }
                      }
                    }
                </script>
                <script type="text/javascript">
                  google.charts.load('current', {'packages':['corechart']});
                  google.charts.setOnLoadCallback(drawChart);

                  function drawChart() {

                    var data = google.visualization.arrayToDataTable([
                        ['Age', 'Case Number'],
                        ['15-20', <?php
                                    $sql=$row=$result='';
                                    $sql="SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=15 and Age<=20 and District='".$_GET['district']."'";
                                    $result = $conn->query($sql);
                                    $row = $result->fetch_assoc();
                                    echo $row['COUNT(Age)'];
                                  ?>],
                        ['21-25', <?php
                                    $sql=$row=$result='';
                                    $sql="SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=21 and Age<=25 and District='".$_GET['district']."'";
                                    $result = $conn->query($sql);
                                    $row = $result->fetch_assoc();
                                    echo $row['COUNT(Age)'];
                                  ?>],
                        ['26-30', <?php
                                    $sql=$row=$result='';
                                    $sql="SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=26 and Age<=30 and District='".$_GET['district']."'";
                                    $result = $conn->query($sql);
                                    $row = $result->fetch_assoc();
                                    echo $row['COUNT(Age)'];
                                  ?>],
                        ['31-35', <?php
                                    $sql=$row=$result='';
                                    $sql="SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=31 and Age<=35 and District='".$_GET['district']."'";
                                    $result = $conn->query($sql);
                                    $row = $result->fetch_assoc();
                                    echo $row['COUNT(Age)'];
                                  ?>],
                        ['36-40', <?php
                                    $sql=$row=$result='';
                                    $sql="SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=36 and Age<=40 and District='".$_GET['district']."'";
                                    $result = $conn->query($sql);
                                    $row = $result->fetch_assoc();
                                    echo $row['COUNT(Age)'];
                                  ?>],
                        ['41-45', <?php
                                    $sql=$row=$result='';
                                    $sql="SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=41 and Age<=45 and District='".$_GET['district']."'";
                                    $result = $conn->query($sql);
                                    $row = $result->fetch_assoc();
                                    echo $row['COUNT(Age)'];
                                  ?>],
                        ['46+', <?php
                                    $sql=$row=$result='';
                                    $sql="SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=46 and District='".$_GET['district']."'";
                                    $result = $conn->query($sql);
                                    $row = $result->fetch_assoc();
                                    echo $row['COUNT(Age)'];
                                  ?>]
                        
                      ]);

                    var options = {
                      title: 'Abortion Statistic',
                      
                    };

                    var chart = new google.visualization.PieChart(document.getElementById('piechart'));

                    chart.draw(data, options);
                  }
                </script>
                <?php
                
              }else if($_GET['filter']=='Religion'){
                ?>
                  <marquee>Total Number of Sample Is: <big><?php
                    $sql=$row=$result='';
                    $sql="SELECT COUNT(name) FROM `abortion_data` WHERE 1";
                    $result = $conn->query($sql);
                    $row = $result->fetch_assoc();
                    echo $row['COUNT(name)'];
                  ?></big> </marquee>
                <script type="text/javascript">
                    google.charts.load('current', {'packages':['bar']});
                    google.charts.setOnLoadCallback(drawChart);

                    

                    function drawChart() {
                      var data = google.visualization.arrayToDataTable([
                        ['Age', 'Muslim', 'Hindu'],
                        ['15-20', <?php
                                    $sql=$row=$result='';
                                    $sql="SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=15 and Age<=20 and Religion='Islam'";
                                    $result = $conn->query($sql);
                                    $row = $result->fetch_assoc();
                                    echo $row['COUNT(Age)'];
                                  ?>, <?php
                                  $sql=$row=$result='';
                                  $sql="SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=15 and Age<=20 and Religion='Hindu'";
                                  $result = $conn->query($sql);
                                  $row = $result->fetch_assoc();
                                  echo $row['COUNT(Age)'];
                                ?>],
                        
                        ['21-25', <?php
                                    $sql=$row=$result='';
                                    $sql="SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=21 and Age<=25 and Religion='Islam'";
                                    $result = $conn->query($sql);
                                    $row = $result->fetch_assoc();
                                    echo $row['COUNT(Age)'];
                                  ?>, <?php
                                  $sql=$row=$result='';
                                  $sql="SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=21 and Age<=25 and Religion='Hindu'";
                                  $result = $conn->query($sql);
                                  $row = $result->fetch_assoc();
                                  echo $row['COUNT(Age)'];
                                ?>],
                        ['26-30', <?php
                                    $sql=$row=$result='';
                                    $sql="SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=26 and Age<=30 and Religion='Islam'";
                                    $result = $conn->query($sql);
                                    $row = $result->fetch_assoc();
                                    echo $row['COUNT(Age)'];
                                  ?>, <?php
                                  $sql=$row=$result='';
                                  $sql="SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=26 and Age<=30 and Religion='Hindu'";
                                  $result = $conn->query($sql);
                                  $row = $result->fetch_assoc();
                                  echo $row['COUNT(Age)'];
                                ?>],
                        ['31-35', <?php
                                    $sql=$row=$result='';
                                    $sql="SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=31 and Age<=35 and Religion='Islam'";
                                    $result = $conn->query($sql);
                                    $row = $result->fetch_assoc();
                                    echo $row['COUNT(Age)'];
                                  ?>, <?php
                                  $sql=$row=$result='';
                                  $sql="SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=31 and Age<=35 and Religion='Hindu'";
                                  $result = $conn->query($sql);
                                  $row = $result->fetch_assoc();
                                  echo $row['COUNT(Age)'];
                                ?>],
                        ['36-40', <?php
                                    $sql=$row=$result='';
                                    $sql="SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=36 and Age<=40 and Religion='Islam'";
                                    $result = $conn->query($sql);
                                    $row = $result->fetch_assoc();
                                    echo $row['COUNT(Age)'];
                                  ?>, <?php
                                  $sql=$row=$result='';
                                  $sql="SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=36 and Age<=40 and Religion='Hindu'";
                                  $result = $conn->query($sql);
                                  $row = $result->fetch_assoc();
                                  echo $row['COUNT(Age)'];
                                ?>],
                        ['41-45', <?php
                                    $sql=$row=$result='';
                                    $sql="SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=41 and Age<=45 and Religion='Islam'";
                                    $result = $conn->query($sql);
                                    $row = $result->fetch_assoc();
                                    echo $row['COUNT(Age)'];
                                  ?>, <?php
                                  $sql=$row=$result='';
                                  $sql="SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=41 and Age<=45 and Religion='Hindu'";
                                  $result = $conn->query($sql);
                                  $row = $result->fetch_assoc();
                                  echo $row['COUNT(Age)'];
                                ?>],
                        ['46+', <?php
                                    $sql=$row=$result='';
                                    $sql="SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=46 and Religion='Islam'";
                                    $result = $conn->query($sql);
                                    $row = $result->fetch_assoc();
                                    echo $row['COUNT(Age)'];
                                  ?>,<?php
                                  $sql=$row=$result='';
                                  $sql="SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=46 and Religion='Hindu'";
                                  $result = $conn->query($sql);
                                  $row = $result->fetch_assoc();
                                  echo $row['COUNT(Age)'];
                                ?>]
                      ]);

                      var options = {
                        chart: {
                          title: 'Abortion Statistic',
                          subtitle: 'Religion Wise',
                        },
                        bars: 'vertical',
                        vAxis: {format: 'decimal',title:'Number Of case'},
                        hAxis:{title:'Age'},
                        height: 400,
                        width: 800,
                        colors: ['#1b9e77','#dc3545']
                      };

                      var chart = new google.charts.Bar(document.getElementById('chart_div'));

                      chart.draw(data, google.charts.Bar.convertOptions(options));

                      var btns = document.getElementById('btn-group');

                      btns.onclick = function (e) {

                        if (e.target.tagName === 'BUTTON') {
                          options.vAxis.format = e.target.id === 'none' ? '' : e.target.id;
                          chart.draw(data, google.charts.Bar.convertOptions(options));
                        }
                      }
                    }
                </script>
                <script type="text/javascript">
                  google.charts.load('current', {'packages':['corechart']});
                  google.charts.setOnLoadCallback(drawChart);

                  function drawChart() {

                    var data = google.visualization.arrayToDataTable([
                        ['Religion','Type'],
                        ["Muslim",<?php
                                    $sql=$row=$result='';
                                    $sql="SELECT COUNT(Age) FROM `abortion_data` WHERE Religion='Islam'";
                                    $result = $conn->query($sql);
                                    $row = $result->fetch_assoc();
                                    echo $row['COUNT(Age)'];
                                  ?>],
                        ["Hindu",<?php
                                    $sql=$row=$result='';
                                    $sql="SELECT COUNT(Age) FROM `abortion_data` WHERE Religion='Hindu'";
                                    $result = $conn->query($sql);
                                    $row = $result->fetch_assoc();
                                    echo $row['COUNT(Age)'];
                                  ?>]
                        
                        ]);

                    var options = {
                      title: 'Abortion Statistic',
                      
                    };

                    var chart = new google.visualization.PieChart(document.getElementById('piechart'));

                    chart.draw(data, options);
                  }
                </script>
                <?php
                
              }else if($_GET['filter']=='Mother_Death'){
                ?>
                  <marquee>Total Number of Sample Is: <big><?php
                    $sql=$row=$result='';
                    $sql="SELECT COUNT(name) FROM `abortion_data` WHERE 1";
                    $result = $conn->query($sql);
                    $row = $result->fetch_assoc();
                    echo $row['COUNT(name)'];
                  ?></big> </marquee>
                <script type="text/javascript">
                    google.charts.load('current', {'packages':['bar']});
                    google.charts.setOnLoadCallback(drawChart);
                    function drawChart() {
                      var data = google.visualization.arrayToDataTable([
                        ['Age', 'Mother_death'],
                        ['15-20', <?php
                                    $sql=$row=$result='';
                                    $sql="SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=15 and Age<=20 and Mother_Death='Yes'";
                                    $result = $conn->query($sql);
                                    $row = $result->fetch_assoc();
                                    echo $row['COUNT(Age)'];
                                  ?>],
                        ['21-25', <?php
                                    $sql=$row=$result='';
                                    $sql="SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=21 and Age<=25 and Mother_Death='Yes'";
                                    $result = $conn->query($sql);
                                    $row = $result->fetch_assoc();
                                    echo $row['COUNT(Age)'];
                                  ?>],
                        ['26-30', <?php
                                    $sql=$row=$result='';
                                    $sql="SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=26 and Age<=30 and Mother_Death='Yes'";
                                    $result = $conn->query($sql);
                                    $row = $result->fetch_assoc();
                                    echo $row['COUNT(Age)'];
                                  ?>],
                        ['31-35', <?php
                                    $sql=$row=$result='';
                                    $sql="SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=31 and Age<=35 and Mother_Death='Yes'";
                                    $result = $conn->query($sql);
                                    $row = $result->fetch_assoc();
                                    echo $row['COUNT(Age)'];
                                  ?>],
                        ['36-40', <?php
                                    $sql=$row=$result='';
                                    $sql="SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=36 and Age<=40 and Mother_Death='Yes'";
                                    $result = $conn->query($sql);
                                    $row = $result->fetch_assoc();
                                    echo $row['COUNT(Age)'];
                                  ?>],
                        ['41-45', <?php
                                    $sql=$row=$result='';
                                    $sql="SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=41 and Age<=45 and Mother_Death='Yes'";
                                    $result = $conn->query($sql);
                                    $row = $result->fetch_assoc();
                                    echo $row['COUNT(Age)'];
                                  ?>],
                        ['46+', <?php
                                    $sql=$row=$result='';
                                    $sql="SELECT COUNT(Age) FROM `abortion_data` WHERE Age>=46 and Mother_Death='Yes'";
                                    $result = $conn->query($sql);
                                    $row = $result->fetch_assoc();
                                    echo $row['COUNT(Age)'];
                                  ?>]
                      ]);

                      var options = {
                        chart: {
                          title: 'Abortion Statistic',
                          subtitle: 'Mother Death Occure',
                        },
                        bars: 'vertical',
                        vAxis: {format: 'decimal',title:'Number Of case'},
                        hAxis:{title:'Age'},
                        height: 400,
                        width: 800,
                        colors: ['#1b9e77','#dc3545']
                      };

                      var chart = new google.charts.Bar(document.getElementById('chart_div'));

                      chart.draw(data, google.charts.Bar.convertOptions(options));

                      var btns = document.getElementById('btn-group');

                      btns.onclick = function (e) {

                        if (e.target.tagName === 'BUTTON') {
                          options.vAxis.format = e.target.id === 'none' ? '' : e.target.id;
                          chart.draw(data, google.charts.Bar.convertOptions(options));
                        }
                      }
                    }
                </script>
                <script type="text/javascript">
                  google.charts.load('current', {'packages':['corechart']});
                  google.charts.setOnLoadCallback(drawChart);

                  function drawChart() {

                    var data = google.visualization.arrayToDataTable([
                        ['Religion','Type'],
                        ["Mother_Death",<?php
                                    $sql=$row=$result='';
                                    $sql="SELECT COUNT(Age) FROM `abortion_data` WHERE Mother_Death='Yes'";
                                    $result = $conn->query($sql);
                                    $row = $result->fetch_assoc();
                                    echo $row['COUNT(Age)'];
                                  ?>],
                        ["No Death",<?php
                                    $sql=$row=$result='';
                                    $sql="SELECT COUNT(Age) FROM `abortion_data` WHERE Mother_Death='No'";
                                    $result = $conn->query($sql);
                                    $row = $result->fetch_assoc();
                                    echo $row['COUNT(Age)'];
                                  ?>]
                        
                        ]);

                    var options = {
                      title: 'Abortion Statistic',
                      
                    };

                    var chart = new google.visualization.PieChart(document.getElementById('piechart'));

                    chart.draw(data, options);
                  }
                </script>
                <?php
                
              }else{
                
              }
            ?>
          </div>
          
          <div class="col-md-8 overflow-auto">
              <div id="chart_div" class="" style="width:auto"></div>
              <label for="" class="pt-3">Change Style of chart</label>
              <div id="btn-group" class="">
                <button class="btn btn-success m-3" id="none">No Format</button>
                <button class=" btn btn-primary m-3" id="scientific">Scientific Notation</button>
                <button class="btn btn-info m-3" id="decimal">Decimal</button>
                <button class="btn btn-secondary m-3" id="short">Short</button>
              </div>
              <!-- <div id="curve_chart" style="width: 900px; height: 500px"></div> -->
              <!-- <div id="piechart" style="width: 900px; height: 500px;"></div> -->
            </div>
            <div class="col-md-4">
              <!-- <div id="chart_div" ></div> -->
              <!-- <div id="curve_chart" style="width: 900px; height: 500px"></div> -->
              <div id="piechart" style="height: 400px;"></div>
            </div>

          
          
        </div>
      </div>    
<?php
  include "footer.php";
?>