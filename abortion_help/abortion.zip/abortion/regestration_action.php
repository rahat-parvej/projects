<?php 
    include "dbcon/dbcon.php";
    if ($_SERVER["REQUEST_METHOD"] == "POST"){
        print_r($_POST);
        $name = filter_var($_POST['Name'], FILTER_SANITIZE_STRING);
        $org_type = filter_var($_POST['Org_Type'], FILTER_SANITIZE_STRING);
        $org_code = filter_var($_POST['Org_Code'], FILTER_SANITIZE_NUMBER_INT);
        $org_code = filter_var($org_code, FILTER_VALIDATE_INT);
        $org_code=(string)$org_code;
        $established= filter_var($_POST['Established'],FILTER_SANITIZE_STRING);
        $established= filter_var($established,FILTER_VALIDATE_INT);
        $division = filter_var($_POST['Division'], FILTER_SANITIZE_STRING);
        $district = filter_var($_POST['District'], FILTER_SANITIZE_STRING);
        $upazila = filter_var($_POST['Upazila'], FILTER_SANITIZE_STRING);
        $union = filter_var($_POST['Union_p'], FILTER_SANITIZE_STRING);
        $ward = filter_var($_POST['Ward'], FILTER_SANITIZE_STRING);
        $house_no = filter_var($_POST['House_No'], FILTER_SANITIZE_STRING);
        $Village_Street = filter_var($_POST['Village_Street'], FILTER_SANITIZE_STRING);
        $Mailing_Address = filter_var($_POST['Mailing_Address'], FILTER_SANITIZE_STRING);
        $mobile = filter_var($_POST['Mobile_Phones'], FILTER_SANITIZE_STRING);
        if(preg_match("/(^(\+88|0088)?(01){1}[3456789]{1}(\d){8})$/", $mobile)) {$mobile=$mobile;}else{$mobile="";}
        $land_Phones=filter_var($_POST['Land_Phones'], FILTER_SANITIZE_STRING);
        $Fax=filter_var($_POST['Faxs'], FILTER_SANITIZE_STRING);
        $website=filter_var($_POST['Website'], FILTER_SANITIZE_URL);
        $website=filter_var($website, FILTER_VALIDATE_URL);
        $email = filter_var($_POST['Email'], FILTER_SANITIZE_EMAIL);
        if(!filter_var($email, FILTER_VALIDATE_EMAIL) === false) {$email=$email;}else{$email="";}
        if($_POST['agreement']=="agree"){
            if($mobile!="" && $email!=""){
                $update="UPDATE `hospital_list` SET `Name`='$name',`Org_Type`='$org_type',`Established`='$established',`Division`='$division',`District`='$district',`Upazila`='$upazila',`Union_p`='$union',`Ward`='$ward',`Village_Street`='$Village_Street',`House_No`='$house_no',`Mailing_Address`='$Mailing_Address',`Land_Phones`='$land_Phones',`Mobile_Phones`='$mobile',`Email`='$email',`Faxs`='$Fax',`Website`='$website' WHERE `Org_Code`='$org_code';";
                function RandomString()
                {
                    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ`!@#&*()-_+={}[]|\:"./?';
                    $randstring = '';
                    for ($i = 0; $i < 8; $i++) {
                        $randstring .= $characters[rand(0, mb_strlen($characters))];
                    }
                    return $randstring;
                }
                $pass1=RandomString();
                $pass=md5($pass1);
        
                $insert="INSERT INTO `user`(`Org_Code`, `email`, `password`) VALUES ('$org_code','$email','$pass')";
                if ($conn->query($update) === TRUE) {
                    if ($conn->query($insert) === TRUE) {
                        
                        // mail sending
                        require 'phpmailer/PHPMailerAutoload.php';
                        $mail = new PHPMailer;
                        $sender_email = 'rahatparvej2@gmail.com';
                        $sender_pass = '11221234121';
                
                        $receiver = $email;
                        // $mail->isSMTP(); // for localhost use enable this line otherwise don't use it
                        $mail->Host = 'smtp.gmail.com';
                        $mail->Port = 465;
                        $mail->SMTPAuth = true;
                        $mail->SMTPSecure = 'tls';
                
                        $mail->Username = $sender_email; // Sender Email Id
                        $mail->Password = $sender_pass; // password of gmail
                
                        $mail->setFrom($sender_email,'Abortion Help');
                
                        $mail->addAddress($receiver); // Receiver Email Address
                        $mail->addReplyTo($sender_email);
                
                        $mail->isHTML(true);
                        $mail->Subject = "Thank You for Registration on Abortion Help";
                        $mail->Body = '<h5>Dear Sir, <br>You have successfully registred on <b>Abortion Help</b>.Here is your login details___ <br> Email: <big>'.$email.' </big><br>Password: <b><big>'.$pass1.'</big></b><br><br> Best Regards,<br> <big>Abortion Help</big></h5>';
                        if($mail->send())
                        {
                            $mail->ClearAddresses();
                            $mail->clearReplyTos();
                            // mail_sent = 1 kore dilam er mane mail sent hoyse.
                            $mail_sent = 1;
                        }
                        
                       
                        echo "<script>alert('Please cheack Your Email For login Information');window.location.replace('login_form.html');</script>";
                    }else{echo "insertt hoy ni";}
                }else{ echo "update hoy ni"; }       
            }
        }else{
            echo "<script>alert('You Must Agree with the Terms and Conditions');window.location.href = 'regestration.php';</script>";
        }

    }
?>