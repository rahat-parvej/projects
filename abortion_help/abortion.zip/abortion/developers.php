
<div class="col-md-12 dev" style="word-spacing: 1cm;">
    Devloped By <span ><a style="word-spacing: 5px;" href="https://www.facebook.com/rahat.parvej.184/" target="_blank" rel="noopener noreferrer"  class="text-decoration-none">Rahat Parvej</a> </span> | <span ><a style="word-spacing: 5px;" href="https://www.facebook.com/sudiptopbb037" target="_blank" rel="noopener noreferrer" class="text-decoration-none">Sudipto Sarker</a></span>
</div>

